0. 0文件为初始场数据，太大，不方便传输，分为0_1和0_2进行了压缩，测试前需要先解压,并将其中文件整合到0文件夹中s
1. 首先source env.sh中的环境
2. 随后根据可用卡数，修改网格分块数，块数在system/decomposeParDict中需修改numberOfSubdomains及simpleCoeffs中的n，例如2块卡，可分别修改为2，（2，1，1）

3. 设置完成后执行decomposeParDict命令（需要有OpenFOAM环境）

4。 提交计算脚本（参考submitDCU）