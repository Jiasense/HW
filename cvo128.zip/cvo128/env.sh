#!/bin/bash

module purge

module load compiler/gnu/9.3.0
module load compiler/intel/2017.5.239 
module load mpi/hpcx/2.11.0/intel-2017.5.239
module load compiler/cmake/3.23.3
module load compiler/dtk/24.04
export MPI_ROOT=/opt/hpc/software/mpi/hpcx/v2.11.0/intel-2017.5.239

export PATH="/public/home/chenzhi/anaconda3/bin:$PATH"

# >>> conda initialize >>>
# !! Contents within this block are managed by 'conda init' !!
__conda_setup="$('/public/home/chenzhi/anaconda3/bin/conda' 'shell.bash' 'hook' 2> /dev/null)"
if [ $? -eq 0 ]; then
    eval "$__conda_setup"
else
    if [ -f "/public/home/chenzhi/anaconda3/etc/profile.d/conda.sh" ]; then
        . "/public/home/chenzhi/anaconda3/etc/profile.d/conda.sh"
    else
        export PATH="/public/home/chenzhi/anaconda3/bin:$PATH"
    fi
fi
unset __conda_setup

conda activate deepflame

# OpenFOAM环境
source /public/home/chenzhi/Lynn/codes/develop/OpenFOAM-7/etc/bashrc

#deepflame主程序，deepflame-dev-dfAcademic和deepflame-dev是一样的，实际计算靠该文件夹下/platforms/linux64GccDPInt32Opt/bin/dfLowMachFoam完成

source /public/home/chenzhi/hekang/DF_Academic/new_code/deepflame-dev-dfAcademic/bashrc

#yaml-cpp环境
export LD_LIBRARY_PATH=/public/home/chenzhi/hekang/DF_Academic/new_code/yaml-cpp/build:$LD_LIBRARY_PATH

#OpenCC-cuda环境
export LD_LIBRARY_PATH=/public/home/chenzhi/hekang/DF_Academic/new_code/OpenCC-cuda/lib:$LD_LIBRARY_PATH
