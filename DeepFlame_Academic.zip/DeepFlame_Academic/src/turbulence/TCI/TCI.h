#pragma once

#include "dfacademic.h"
#include "common.h"
#include "boundary.h"
#include "basic.h"
#include "turbulence.h"

class TCIModel {
public:
    TCIModel() {};
    virtual ~TCIModel() {};

    virtual void calculate_SGS_RR(DF_REAL *RR, const DF_REAL *k, const DF_REAL *epsilon, 
            const DF_REAL *mu, const DF_REAL *rho, const DF_REAL *y) = 0;
};

class WSRModel : public TCIModel 
{
public:
    WSRModel() {};
    virtual ~WSRModel() {};
    void calculate_SGS_RR(DF_REAL *RR, const DF_REAL *k, const DF_REAL *epsilon, 
            const DF_REAL *mu, const DF_REAL *rho, const DF_REAL *y)
    {
        // nothing need to be done
    }
};

class PaSRModel : public TCIModel 
{
public:    
    PaSRModel() {};
    virtual ~PaSRModel() {};
    void calculate_SGS_RR(DF_REAL *RR, const DF_REAL *k, const DF_REAL *epsilon, 
            const DF_REAL *mu, const DF_REAL *rho, const DF_REAL *y) override;
};

class infinitelyFastChemistryModel : public TCIModel 
{
public:    
    infinitelyFastChemistryModel() {};
    virtual ~infinitelyFastChemistryModel() {};
    void calculate_SGS_RR(DF_REAL *RR, const DF_REAL *k, const DF_REAL *epsilon, 
            const DF_REAL *mu, const DF_REAL *rho, const DF_REAL *y) override;
    void calculate_HRR(DF_REAL *HRR, DF_REAL *RR, const DF_REAL *y);
};
