#pragma once

#include "dfacademic.h"
#include "common.h"
#include "boundary.h"
#include "basic.h"
#include "turbulence.h"
#include "solver.h"

class LESModel
{
public:
    LESModel() {};
    virtual ~LESModel() {};

    virtual void solve_k(const DF_REAL *grad_u, const DF_REAL Ce, DF_REAL *k, DF_REAL *delta) = 0;

    virtual void correct_turbulence(const DF_REAL *k, const DF_REAL *delta, const DF_REAL Ck,
                                    const DF_REAL Prt, DF_REAL *nut, DF_REAL *mut, DF_REAL *alphat,
                                    DF_REAL *boundary_nut, DF_REAL *boundary_mut, DF_REAL *boundary_alphat,
                                    int *patch_type_nut, int *patch_type_alphat,
                                    const DF_REAL *grad_u = nullptr, bool useOld = false) = 0;

    virtual void calculate_k_epsilon(const DF_REAL *grad_u, const DF_REAL Ce, const DF_REAL Ck,
                                     DF_REAL *k, DF_REAL *epsilon, DF_REAL *delta) = 0;
};

class Smagorinsky : public LESModel
{
public:
    Smagorinsky()
    {
        if (turbulence_ptr.k == nullptr)
        {
            checkCudaErrors(cudaMalloc(&turbulence_ptr.k, sizeof(DF_REAL) * meshBase.num_cells));
        }
        if (turbulence_ptr.epsilon == nullptr)
        {
            checkCudaErrors(cudaMalloc(&turbulence_ptr.epsilon, sizeof(DF_REAL) * meshBase.num_cells));
        }
        if (turbulence_ptr.delta == nullptr)
        {
            checkCudaErrors(cudaMalloc(&turbulence_ptr.delta, sizeof(DF_REAL) * meshBase.num_cells));
        }
    };
    virtual ~Smagorinsky() {};

    void solve_k(const DF_REAL *grad_u, const DF_REAL Ce, DF_REAL *k, DF_REAL *delta) {};

    void calculate_k_epsilon(const DF_REAL *grad_u, const DF_REAL Ce, const DF_REAL Ck,
                             DF_REAL *k, DF_REAL *epsilon, DF_REAL *delta) override;

    void correct_turbulence(const DF_REAL *k, const DF_REAL *delta, const DF_REAL Ck,
                            const DF_REAL Prt, DF_REAL *nut, DF_REAL *mut, DF_REAL *alphat,
                            DF_REAL *boundary_nut, DF_REAL *boundary_mut, DF_REAL *boundary_alphat,
                            int *patch_type_nut, int *patch_type_alphat,
                            const DF_REAL *grad_u = nullptr, bool useOld = false) override;
};

class Sigma : public LESModel
{
public:
    Sigma()
    {
        if (turbulence_ptr.delta == nullptr)
        {
            checkCudaErrors(cudaMalloc(&turbulence_ptr.delta, sizeof(DF_REAL) * meshBase.num_cells));
        }
    };
    virtual ~Sigma() {};

    void solve_k(const DF_REAL *grad_u, const DF_REAL Ce, DF_REAL *k, DF_REAL *delta) {};

    void calculate_k_epsilon(const DF_REAL *grad_u, const DF_REAL Ce, const DF_REAL Ck,
                             DF_REAL *k, DF_REAL *epsilon, DF_REAL *delta) override;

    void correct_turbulence(const DF_REAL *k, const DF_REAL *delta, const DF_REAL Ck,
                            const DF_REAL Prt, DF_REAL *nut, DF_REAL *mut, DF_REAL *alphat,
                            DF_REAL *boundary_nut, DF_REAL *boundary_mut, DF_REAL *boundary_alphat,
                            int *patch_type_nut, int *patch_type_alphat,
                            const DF_REAL *grad_u = nullptr, bool useOld = false) override;
};

class kEqnModel : public LESModel
{
public:
    kEqnModel()
    {
        if (turbulence_ptr.delta == nullptr)
        {
            checkCudaErrors(cudaMalloc(&turbulence_ptr.delta, sizeof(DF_REAL) * meshBase.num_cells));
        }
        if (turbulence_ptr.k == nullptr)
        {
            checkCudaErrors(cudaMalloc(&turbulence_ptr.k, sizeof(DF_REAL) * meshBase.num_cells));
            checkCudaErrors(cudaMalloc(&turbulence_ptr.k_old, sizeof(DF_REAL) * meshBase.num_cells));
        }
        if (turbulence_ptr.epsilon == nullptr)
        {
            checkCudaErrors(cudaMalloc(&turbulence_ptr.epsilon, sizeof(DF_REAL) * meshBase.num_cells));
            checkCudaErrors(cudaMalloc(&turbulence_ptr.epsilon_old, sizeof(DF_REAL) * meshBase.num_cells));
        }
        checkCudaErrors(cudaMalloc(&turbulence_ptr.G, meshBase.num_cells * sizeof(DF_REAL)));
        checkCudaErrors(cudaMalloc(&turbulence_ptr.boundary_k, meshBase.num_boundary_surfaces * sizeof(DF_REAL)));
        checkCudaErrors(cudaMalloc(&turbulence_ptr.boundary_epsilon, meshBase.num_boundary_surfaces * sizeof(DF_REAL)));
    };
    virtual ~kEqnModel() {};

    // intermediate values
    DF_REAL *divU = nullptr;
    DF_REAL *tmp_k_coeff_1 = nullptr;
    DF_REAL *tmp_k_coeff_2 = nullptr;
    DF_REAL *tmp_k_coeff_3 = nullptr;
    DF_REAL *tmp_k_coeff_4 = nullptr;
    DF_REAL *tmp_boundary_k_coeff_1 = nullptr;

    DF_REAL *d_Phibyrho = nullptr;
    DF_REAL *d_boundaryPhibyrho = nullptr;

    void initStart();
    void setZero();
    void init();
    void freeinit();
    void calculate_divU();
    void assembly_EqK(DF_REAL *k);
    void solve_EqK(DF_REAL *k);
    void solve_k(const DF_REAL *grad_u, const DF_REAL Ce, DF_REAL *k, DF_REAL *delta) override;

    void calculate_k_epsilon(const DF_REAL *grad_u, const DF_REAL Ce, const DF_REAL Ck,
                             DF_REAL *k, DF_REAL *epsilon, DF_REAL *delta) override;

    void correct_turbulence(const DF_REAL *k, const DF_REAL *delta, const DF_REAL Ck,
                            const DF_REAL Prt, DF_REAL *nut, DF_REAL *mut, DF_REAL *alphat,
                            DF_REAL *boundary_nut, DF_REAL *boundary_mut, DF_REAL *boundary_alphat,
                            int *patch_type_nut, int *patch_type_alphat,
                            const DF_REAL *grad_u = nullptr, bool useOld = false) override;
};

extern solver_d solver_kLES;
