#pragma once

class LESModel;
class RASModel;
class TCIModel;

#include "dfacademic.h"
#include "common.h"
#include "boundary.h"
#include "basic.h"

class turbulence_base
{
public:
    turbulence_base() {};
    virtual ~turbulence_base() {};

    void set_turbulence(LES_TURBULENCE_MODEL&);
    void set_turbulence(RAS_TURBULENCE_MODEL&);
    void calculate_LESdelta();

    void compute_DEff(const DF_REAL sct, DF_REAL *rhoD, DF_REAL *mut, DF_REAL *DEff,
        DF_REAL *boundary_rhoD, DF_REAL *boundary_mut, DF_REAL *boundary_DEff);

    void compute_alphaEff(DF_REAL *alpha, DF_REAL *alphat, DF_REAL *alphaEff,
        DF_REAL *boundary_alpha, DF_REAL *boundary_alphat, DF_REAL *boundary_alphaEff);

    void compute_muEff(DF_REAL *mu, DF_REAL *mut, DF_REAL *muEff,
        DF_REAL *boundary_mu, DF_REAL *boundary_mut, DF_REAL *boundary_muEff);

    LESModel *model_LES = nullptr;
    RASModel *model_RAS = nullptr;
    
    bool use_turbulence_model = false;
    bool use_TCI_model = false;

    // internal turbulence variables
    DF_REAL *nut = nullptr;
    DF_REAL *mut = nullptr;
    DF_REAL *alphat = nullptr;

    // boundary turbulence variables
    DF_REAL *boundary_nut = nullptr;;
    DF_REAL *boundary_mut = nullptr;
    DF_REAL *boundary_alphat = nullptr;
    DF_REAL *boundary_k = nullptr;
    DF_REAL *boundary_epsilon = nullptr;

    DF_REAL *boundary_yDist = nullptr; 
    DF_REAL *boundary_cornerWeights = nullptr;

    // boundary conditions
    int *patch_type_nut = nullptr;
    int *patch_type_alphat = nullptr;
    int *patch_type_k = nullptr;
    int *patch_type_epsilon = nullptr;
    DF_REAL *patch_refValue_k = nullptr;

    // turbulence parameters
    DF_REAL *k = nullptr;          // smagorinsky
    DF_REAL *epsilon = nullptr;    // smagorinsky
    DF_REAL *k_old = nullptr;          
    DF_REAL *epsilon_old = nullptr; 
    DF_REAL *delta = nullptr;
    DF_REAL *G = nullptr;

    DF_REAL Ce = 1.048;
    DF_REAL Ck = 0.094;
    DF_REAL Sct = 1.;
    DF_REAL Prt = 1.;

    DF_REAL Cmu = 0.09;
    DF_REAL C1 = 1.44;
    DF_REAL C2 = 1.92;
    DF_REAL C3 = 0.0;
    DF_REAL sigmaK = 1.0;
    DF_REAL sigmaEpsilon = 1.3;

    DF_REAL yPlusLam = 11.0;
    DF_REAL E = 9.8;
    DF_REAL kappa = 0.41;

    DF_REAL *mixingLength = nullptr;
    DF_REAL *intensity = nullptr;
};

void correct_turbulence(
    const DF_REAL *grad_u, bool useOld = false
);

void calculate_k_epsilon(
    const DF_REAL *grad_u
);

void calculate_muEff(
    DF_REAL *muEff, 
    DF_REAL *boundary_muEff
);

void calculate_alphaEff(
    DF_REAL *alphaEff, 
    DF_REAL *boundary_alphaEff
);

void calculate_DEff(
    DF_REAL *DEff, 
    DF_REAL *boundary_DEff
);

class combustion_base : public turbulence_base
{
public:
    combustion_base() {};
    virtual ~combustion_base() {};

    TCIModel *model_TCI = nullptr;
    void set_combustion_model(TCI_MODEL&);

    // infinitelyFastChemistryModel
    int O2Index; 
    int fuelIndex; 
    int *reactants; 
    int *products; // [num_species]
    DF_REAL s_; 
    DF_REAL stoicRatio_; 
    DF_REAL C_; 
    DF_REAL qFuel_;
    DF_REAL *fres; // [num_cells*num_species]
    DF_REAL *Yprod0; // [num_species]
    DF_REAL *specieStoichCoeffs; // [num_species]
    
    void init_infinitelyFastChemistry_combustion(infinitelyFastChemistry_data_para input_data);
};

void calculate_SGS_RR(DF_REAL *RR);


extern turbulence_base turbulence_ptr;
extern combustion_base combustion_ptr;
