#pragma once

#include "dfacademic.h"
#include "common.h"
#include "boundary.h"
#include "basic.h"
#include "turbulence.h"
#include "solver.h"

class RASModel
{
public:
    RASModel() {};
    virtual ~RASModel() {};

    virtual void calculate_k_epsilon(const DF_REAL *grad_u, const DF_REAL *nut, const DF_REAL C1, const DF_REAL C2,
                                     const DF_REAL C3, const DF_REAL Cmu, const DF_REAL sigmaK, const DF_REAL sigmaEpsilon,
                                     DF_REAL *k, DF_REAL *epsilon) = 0;

    virtual void correct_turbulence(const DF_REAL Cmu, const DF_REAL Prt,
                                    DF_REAL *k, DF_REAL *epsilon, DF_REAL *nut, DF_REAL *mut, DF_REAL *alphat,
                                    DF_REAL *boundary_nut, DF_REAL *boundary_mut, DF_REAL *boundary_alphat,
                                    int *patch_type_nut, int *patch_type_alphat, bool useOld = false) = 0;
    void initStart();
};

class kEpsilon : public RASModel
{
public:
    kEpsilon()
    {
        if (turbulence_ptr.k == nullptr)
        {
            checkCudaErrors(cudaMalloc(&turbulence_ptr.k, sizeof(DF_REAL) * meshBase.num_cells));
            checkCudaErrors(cudaMalloc(&turbulence_ptr.k_old, sizeof(DF_REAL) * meshBase.num_cells));
        }
        if (turbulence_ptr.epsilon == nullptr)
        {
            checkCudaErrors(cudaMalloc(&turbulence_ptr.epsilon, sizeof(DF_REAL) * meshBase.num_cells));
            checkCudaErrors(cudaMalloc(&turbulence_ptr.epsilon_old, sizeof(DF_REAL) * meshBase.num_cells));
        }
        checkCudaErrors(cudaMalloc(&turbulence_ptr.G, meshBase.num_cells * sizeof(DF_REAL)));
        checkCudaErrors(cudaMalloc(&turbulence_ptr.boundary_k, meshBase.num_boundary_surfaces * sizeof(DF_REAL)));
        checkCudaErrors(cudaMalloc(&turbulence_ptr.boundary_epsilon, meshBase.num_boundary_surfaces * sizeof(DF_REAL)));
    };
    virtual ~kEpsilon() {};

    // intermediate values
    DF_REAL *divU = nullptr;
    DF_REAL *tmp_epsilon_coeff_1 = nullptr;
    DF_REAL *tmp_epsilon_coeff_2 = nullptr;
    DF_REAL *tmp_epsilon_coeff_3 = nullptr;
    DF_REAL *tmp_epsilon_coeff_4 = nullptr;
    DF_REAL *tmp_k_coeff_1 = nullptr;
    DF_REAL *tmp_k_coeff_2 = nullptr;
    DF_REAL *tmp_k_coeff_3 = nullptr;
    DF_REAL *tmp_k_coeff_4 = nullptr;

    DF_REAL *tmp_boundary_epsilon_coeff_1 = nullptr;
    DF_REAL *tmp_boundary_k_coeff_1 = nullptr;

    DF_REAL *d_Phibyrho = nullptr;
    DF_REAL *d_boundaryPhibyrho = nullptr;

    void initStart();
    void setZero();
    void init();
    void freeinit();
    void calculate_divU();
    void assembly_EqEpsilon(DF_REAL *epsilon);
    void solve_EqEpsilon(DF_REAL *epsilon);
    void assembly_EqK(DF_REAL *k);
    void solve_EqK(DF_REAL *k);
    void calculate_k_epsilon(const DF_REAL *grad_u, const DF_REAL *nut, const DF_REAL C1, const DF_REAL C2,
                             const DF_REAL C3, const DF_REAL Cmu, const DF_REAL sigmaK, const DF_REAL sigmaEpsilon,
                             DF_REAL *k, DF_REAL *epsilon);
    void correct_turbulence(const DF_REAL Cmu, const DF_REAL Prt,
                            DF_REAL *k, DF_REAL *epsilon, DF_REAL *nut, DF_REAL *mut, DF_REAL *alphat,
                            DF_REAL *boundary_nut, DF_REAL *boundary_mut, DF_REAL *boundary_alphat,
                            int *patch_type_nut, int *patch_type_alphat, bool useOld = false);

#ifdef USE_GRAPH
    // one graph for one eqn before using self-developed solver
    cudaGraph_t graph_pre, graph_mid, graph_post;
    cudaGraphExec_t graph_instance_pre, graph_instance_mid, graph_instance_post;
    bool pre_graph_created = false;
    bool mid_graph_created = false;
    bool post_graph_created = false;
#endif
};

// k and epsilon solver
extern solver_d solver_k;
extern solver_d solver_epsilon;