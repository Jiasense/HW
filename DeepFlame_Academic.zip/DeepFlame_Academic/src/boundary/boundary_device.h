#include "dfacademic.h"
#include "common.h"

#ifndef _BOUNDARY_DEVICE_H
#define _BOUNDARY_DEVICE_H

inline __device__ void get_snGrad_vector_zeroGradient(DF_REAL *snGrad)
{
    snGrad[0] = 0.0;
    snGrad[1] = 0.0;
    snGrad[2] = 0.0;
}

inline __device__ void get_snGrad_vector_fixedValue(int patchIndex, int num_cells, int num_boundary_surfaces, int *face2cells,
                                                    DF_REAL *inputVector, DF_REAL *snGrad, DF_REAL *boundary_vf, DF_REAL *boundary_deltaCoeffs)
{
    int cellIndex = face2cells[patchIndex];
    DF_REAL deltaCoeffs = boundary_deltaCoeffs[patchIndex];

    snGrad[0] = deltaCoeffs * (boundary_vf[num_boundary_surfaces * 0 + patchIndex] - inputVector[num_cells * 0 + cellIndex]);
    snGrad[1] = deltaCoeffs * (boundary_vf[num_boundary_surfaces * 1 + patchIndex] - inputVector[num_cells * 1 + cellIndex]);
    snGrad[2] = deltaCoeffs * (boundary_vf[num_boundary_surfaces * 2 + patchIndex] - inputVector[num_cells * 2 + cellIndex]);
}

inline __device__ void get_snGrad_vector_noSlip(int patchIndex, int num_cells, int num_boundary_surfaces, int *face2cells,
                                                DF_REAL *inputVector, DF_REAL *snGrad, DF_REAL *boundary_vf, DF_REAL *boundary_deltaCoeffs)
{
    int cellIndex = face2cells[patchIndex];
    DF_REAL deltaCoeffs = boundary_deltaCoeffs[patchIndex];

    snGrad[0] = deltaCoeffs * (0.0 - inputVector[num_cells * 0 + cellIndex]);
    snGrad[1] = deltaCoeffs * (0.0 - inputVector[num_cells * 1 + cellIndex]);
    snGrad[2] = deltaCoeffs * (0.0 - inputVector[num_cells * 2 + cellIndex]);
}

inline __device__ void get_snGrad_vector_pressureInletOutlet(int patchIndex, int num_cells, int num_boundary_surfaces, int *face2cells,
                                                             DF_REAL *inputVector, DF_REAL *snGrad, DF_REAL *bouPhi,
                                                             DF_REAL *bouSf, DF_REAL *bouMagSf, DF_REAL *boundary_deltaCoeffs)
{
    int neg_phip = (bouPhi[patchIndex] < 0) ? 1 : 0;
    int cellIndex = face2cells[patchIndex];
    DF_REAL deltaCoeffs = boundary_deltaCoeffs[patchIndex];

    DF_REAL nf_x = bouSf[num_boundary_surfaces * 0 + patchIndex] / bouMagSf[patchIndex];
    DF_REAL nf_y = bouSf[num_boundary_surfaces * 1 + patchIndex] / bouMagSf[patchIndex];
    DF_REAL nf_z = bouSf[num_boundary_surfaces * 2 + patchIndex] / bouMagSf[patchIndex];

    DF_REAL valueFraction_XX = neg_phip * (1 - nf_x * nf_x);
    DF_REAL valueFraction_YY = neg_phip * (1 - nf_y * nf_y);
    DF_REAL valueFraction_ZZ = neg_phip * (1 - nf_z * nf_z);

    DF_REAL pif_x = inputVector[num_cells * 0 + cellIndex];
    DF_REAL pif_y = inputVector[num_cells * 1 + cellIndex];
    DF_REAL pif_z = inputVector[num_cells * 2 + cellIndex];

    DF_REAL transformGradValue_x = (1.0 - valueFraction_XX) * pif_x;
    DF_REAL transformGradValue_y = (1.0 - valueFraction_YY) * pif_y;
    DF_REAL transformGradValue_z = (1.0 - valueFraction_ZZ) * pif_z;

    snGrad[0] = (transformGradValue_x - pif_x) * deltaCoeffs;
    snGrad[1] = (transformGradValue_y - pif_y) * deltaCoeffs;
    snGrad[2] = (transformGradValue_z - pif_z) * deltaCoeffs;
}

inline __device__ void get_snGrad_vector_wedge(int patchIndex, int num_cells, int *face2cells,
                                               DF_REAL *inputVector, DF_REAL *snGrad, DF_REAL *cellT, DF_REAL *boundary_deltaCoeffs)
{
    int cellIndex = face2cells[patchIndex];
    DF_REAL deltaCoeffs = boundary_deltaCoeffs[patchIndex];

    DF_REAL pif_x = inputVector[num_cells * 0 + cellIndex];
    DF_REAL pif_y = inputVector[num_cells * 1 + cellIndex];
    DF_REAL pif_z = inputVector[num_cells * 2 + cellIndex];

    DF_REAL snGradx = cellT[0] * pif_x + cellT[1] * pif_y + cellT[2] * pif_z;
    DF_REAL snGrady = cellT[3] * pif_x + cellT[4] * pif_y + cellT[5] * pif_z;
    DF_REAL snGradz = cellT[6] * pif_x + cellT[7] * pif_y + cellT[8] * pif_z;

    snGrad[0] = (snGradx - pif_x) * 0.5 * deltaCoeffs;
    snGrad[1] = (snGrady - pif_y) * 0.5 * deltaCoeffs;
    snGrad[2] = (snGradz - pif_z) * 0.5 * deltaCoeffs;
}

inline __device__ void get_snGrad_vector_cyclic(int internal_offset, int neighbor_offset, int index, int num_cells, int *face2Cells,
                                                DF_REAL *inputVector, DF_REAL *snGrad, DF_REAL *boundary_deltaCoeffs)
{
    int internal_start_index = internal_offset + index;
    int neighbor_start_index = neighbor_offset + index;

    int internal_cellIndex = face2Cells[internal_start_index];
    int neighbor_cellIndex = face2Cells[neighbor_start_index];

    DF_REAL deltaCoeffs = boundary_deltaCoeffs[internal_start_index];

    snGrad[0] = deltaCoeffs * (inputVector[num_cells * 0 + neighbor_cellIndex] - inputVector[num_cells * 0 + internal_cellIndex]);
    snGrad[1] = deltaCoeffs * (inputVector[num_cells * 1 + neighbor_cellIndex] - inputVector[num_cells * 1 + internal_cellIndex]);
    snGrad[2] = deltaCoeffs * (inputVector[num_cells * 2 + neighbor_cellIndex] - inputVector[num_cells * 2 + internal_cellIndex]);
}

inline __device__ void get_snGrad_vector_processor(int patchIndex, int num, int num_cells, int num_boundary_surfaces, int *face2Cells,
                                                   DF_REAL *inputVector, DF_REAL *snGrad, DF_REAL *boundary_vf, DF_REAL *boundary_deltaCoeffs)
{
    int neighbor_start_index = patchIndex;
    int internal_start_index = patchIndex + num;
    int internal_cellIndex = face2Cells[internal_start_index];

    DF_REAL deltaCoeffs = boundary_deltaCoeffs[internal_start_index];

    snGrad[0] = deltaCoeffs * (boundary_vf[num_boundary_surfaces * 0 + neighbor_start_index] - inputVector[num_cells * 0 + internal_cellIndex]);
    snGrad[1] = deltaCoeffs * (boundary_vf[num_boundary_surfaces * 1 + neighbor_start_index] - inputVector[num_cells * 1 + internal_cellIndex]);
    snGrad[2] = deltaCoeffs * (boundary_vf[num_boundary_surfaces * 2 + neighbor_start_index] - inputVector[num_cells * 2 + internal_cellIndex]);
}

inline __device__ void get_snGrad_vector(int patch_type, DF_REAL *inputVector, DF_REAL *snGrad, DF_REAL *boundary_vf, DF_REAL *cellT,
                                         int patchIndex, int num_cells, int num_boundary_surfaces, int index, int cyclicOffset, int num,
                                         int *face2cells, DF_REAL *bouPhi, DF_REAL *bouSf, DF_REAL *bouMagSf, DF_REAL *boundary_deltaCoeffs)
{
    switch (patch_type)
    {
    case zeroGradient:
        get_snGrad_vector_zeroGradient(snGrad);
        break;

    case fixedValue:
        get_snGrad_vector_fixedValue(patchIndex, num_cells, num_boundary_surfaces, face2cells,
                                     inputVector, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case noSlip:
        get_snGrad_vector_noSlip(patchIndex, num_cells, num_boundary_surfaces, face2cells,
                                 inputVector, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case flowRateInletVelocity:
        get_snGrad_vector_fixedValue(patchIndex, num_cells, num_boundary_surfaces, face2cells,
                                     inputVector, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case calculated:
        get_snGrad_vector_fixedValue(patchIndex, num_cells, num_boundary_surfaces, face2cells,
                                     inputVector, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case extrapolated:
        get_snGrad_vector_zeroGradient(snGrad);
        break;

    case pressureInletOutlet:
        get_snGrad_vector_pressureInletOutlet(patchIndex, num_cells, num_boundary_surfaces, face2cells, inputVector, snGrad,
                                              bouPhi, bouSf, bouMagSf, boundary_deltaCoeffs);
        break;

    case cyclic:
        get_snGrad_vector_cyclic(patchIndex, cyclicOffset, index, num_cells, face2cells,
                                 inputVector, snGrad, boundary_deltaCoeffs);
        break;

    case processor:
        get_snGrad_vector_processor(patchIndex, num, num_cells, num_boundary_surfaces, face2cells,
                                    inputVector, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case processorCyclic:
        get_snGrad_vector_processor(patchIndex, num, num_cells, num_boundary_surfaces, face2cells,
                                    inputVector, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case wedge:
        get_snGrad_vector_wedge(patchIndex, num_cells, face2cells,
                                inputVector, snGrad, cellT, boundary_deltaCoeffs);
        break;

    default:
        break;
    }
}

inline __device__ void get_snGrad_scalar_zeroGradient(DF_REAL &snGrad)
{
    snGrad = 0.0;
}

inline __device__ void get_snGrad_scalar_fixedValue(int patchIndex, int *face2cells,
                                                    DF_REAL *input, DF_REAL &snGrad, DF_REAL *boundary_vf, DF_REAL *boundary_deltaCoeffs)
{
    int cellIndex = face2cells[patchIndex];
    DF_REAL deltaCoeffs = boundary_deltaCoeffs[patchIndex];

    snGrad = deltaCoeffs * (boundary_vf[patchIndex] - input[cellIndex]);
}

inline __device__ void get_snGrad_scalar_fixedGradient(int patchIndex, DF_REAL *boundary_grad, DF_REAL &snGrad)
{
    snGrad = boundary_grad[patchIndex];
}

inline __device__ void get_snGrad_scalar_inletOutlet(int patchIndex, int *face2cells, DF_REAL *input, DF_REAL &snGrad, DF_REAL inletValue,
                                                     DF_REAL *boundary_vf, DF_REAL *boundary_deltaCoeffs, DF_REAL *bouPhi)
{
    int cellIndex = face2cells[patchIndex];
    int pos0_phi = (bouPhi[patchIndex] >= 0) ? 1 : 0;

    DF_REAL refValue = inletValue;
    DF_REAL valueFraction = 1.0 - pos0_phi;
    DF_REAL bouDeltaCoeffs = boundary_deltaCoeffs[patchIndex];

    snGrad = valueFraction * (refValue - input[cellIndex]) * bouDeltaCoeffs;
}

inline __device__ void get_snGrad_scalar_totalFlowRateAdvectiveDiffusive(int patchIndex, int *face2cells, DF_REAL *input, DF_REAL &snGrad, DF_REAL massFluxFraction,
                                                                         DF_REAL *boundary_vf, DF_REAL *boundary_deltaCoeffs, DF_REAL *bouPhi, DF_REAL *bouAlphaEff, DF_REAL *bouMagSf)
{
    int cellIndex = face2cells[patchIndex];
    DF_REAL bouDeltaCoeffs = boundary_deltaCoeffs[patchIndex];
    DF_REAL magPhip = fabs(bouPhi[patchIndex]);

    DF_REAL refValue = massFluxFraction;
    DF_REAL valueFraction = 1.0 / (1.0 + bouAlphaEff[patchIndex] * bouDeltaCoeffs * bouMagSf[patchIndex] / fmaxf(magPhip, SMALL));

    snGrad = valueFraction * (refValue - input[cellIndex]) * bouDeltaCoeffs;
}

inline __device__ void get_snGrad_scalar_cyclic(int internal_offset, int neighbor_offset, int index, int *face2Cells,
                                                DF_REAL *input, DF_REAL &snGrad, DF_REAL *boundary_deltaCoeffs)
{
    int internal_start_index = internal_offset + index;
    int neighbor_start_index = neighbor_offset + index;

    int internal_cellIndex = face2Cells[internal_start_index];
    int neighbor_cellIndex = face2Cells[neighbor_start_index];

    DF_REAL deltaCoeffs = boundary_deltaCoeffs[internal_start_index];

    snGrad = deltaCoeffs * (input[neighbor_cellIndex] - input[internal_cellIndex]);
}

inline __device__ void get_snGrad_scalar_processor(int patchIndex, int num, int *face2Cells,
                                                   DF_REAL *input, DF_REAL &snGrad, DF_REAL *boundary_vf, DF_REAL *boundary_deltaCoeffs)
{
    int neighbor_start_index = patchIndex;
    int internal_start_index = patchIndex + num;
    int internal_cellIndex = face2Cells[internal_start_index];

    DF_REAL deltaCoeffs = boundary_deltaCoeffs[internal_start_index];

    snGrad = deltaCoeffs * (boundary_vf[neighbor_start_index] - input[internal_cellIndex]);
}

inline __device__ void get_snGrad_scalar(int patch_type, DF_REAL *input, DF_REAL &snGrad, DF_REAL *boundary_vf,
                                         int patchIndex, int index, int cyclicOffset, int num,
                                         int *face2cells, DF_REAL *boundary_deltaCoeffs, DF_REAL *bouPhi,
                                         DF_REAL *bouAlphaEff, DF_REAL *bouMagSf, DF_REAL bouRefValue, DF_REAL *boundary_grad)
{
    switch (patch_type)
    {
    case zeroGradient:
        get_snGrad_scalar_zeroGradient(snGrad);
        break;

    case fixedValue:
        get_snGrad_scalar_fixedValue(patchIndex, face2cells,
                                     input, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case calculated:
        get_snGrad_scalar_fixedValue(patchIndex, face2cells,
                                     input, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case totalPressure:
        get_snGrad_scalar_fixedValue(patchIndex, face2cells,
                                     input, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case prghTotalHydrostaticPressure:
        get_snGrad_scalar_fixedValue(patchIndex, face2cells,
                                     input, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case fixedFluxPressure:
        get_snGrad_scalar_fixedGradient(patchIndex, boundary_grad, snGrad);
        break;

    case extrapolated:
        get_snGrad_scalar_zeroGradient(snGrad);
        break;

    case cyclic:
        get_snGrad_scalar_cyclic(patchIndex, cyclicOffset, index, face2cells,
                                 input, snGrad, boundary_deltaCoeffs);
        break;

    case processor:
        get_snGrad_scalar_processor(patchIndex, num, face2cells,
                                    input, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case processorCyclic:
        get_snGrad_scalar_processor(patchIndex, num, face2cells,
                                    input, snGrad, boundary_vf, boundary_deltaCoeffs);
        break;

    case wedge:
        get_snGrad_scalar_zeroGradient(snGrad);
        break;

    case inletOutlet:
        get_snGrad_scalar_inletOutlet(patchIndex, face2cells, input, snGrad, bouRefValue,
                                      boundary_vf, boundary_deltaCoeffs, bouPhi);
        break;

    case totalFlowRateAdvectiveDiffusive:
        get_snGrad_scalar_totalFlowRateAdvectiveDiffusive(patchIndex, face2cells, input, snGrad, bouRefValue,
                                                          boundary_vf, boundary_deltaCoeffs, bouPhi, bouAlphaEff, bouMagSf);
        break;

    default:
        break;
    }
}

#endif //_BOUNDARY_DEVICE_H