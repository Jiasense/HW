#include "dfacademic.h"
#include "common.h"

#ifndef _BOUNDARY_H
#define _BOUNDARY_H

void correct_boundary_conditions(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value, DF_REAL *boundary_grad = nullptr, DF_REAL *boundary_refValue = nullptr);
void correct_boundary_conditions_basic(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value, DF_REAL *boundary_grad = nullptr, DF_REAL *boundary_refValue = nullptr);

void correct_boundary_conditions_vector(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value, DF_REAL *boundary_grad = nullptr);
void correct_boundary_conditions_basic_vector(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value, DF_REAL *boundary_grad = nullptr);

void correct_boundary_conditions_tensor(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value, DF_REAL *boundary_grad = nullptr);
void correct_boundary_conditions_basic_tensor(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value, DF_REAL *boundary_grad = nullptr);

void correct_boundary_conditions_processor(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value);
void correct_boundary_conditions_basic_processor(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value);

void correct_boundary_conditions_turbulence(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value, DF_REAL *boundary_refValue = nullptr);
void correct_boundary_conditions_turbulence_basic(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value, DF_REAL *boundary_refValue = nullptr);
void correct_boundary_conditions_turbulence_epsilonWallFunction(int *patch_type, DF_REAL *cellValue, DF_REAL *boundary_value);

#endif //_BOUNDARY_H