#ifndef _DFPEQN_H
#define _DFPEQN_H

#include "solver.h"

class dfpEqn : public solver_d
{
public:
    dfpEqn() {}
    virtual ~dfpEqn() {}

    void process();

    DF_REAL *d_rhorAUf = nullptr;
    DF_REAL *d_phiHbyA = nullptr;
    DF_REAL *d_flux = nullptr;
    DF_REAL *d_phig = nullptr;

    DF_REAL *d_boundary_rhorAUf = nullptr;
    DF_REAL *d_boundary_phiHbyA = nullptr;
    DF_REAL *d_boundary_flux = nullptr;
    DF_REAL *d_boundary_phig = nullptr;

    void initStart();

protected:
    void setZero();

    void init();

    void freeinit();

    void assembly();

    void solve();

    void correctBCs();

    void getrhorAUf();

    void getphiHbyA();

    void getdpdt();

    void getsnGradp();

    void updatePhi();

    void correctVelocity();

    void correctPressure();

    void calculate_phig(DF_REAL *rhorAUf, DF_REAL *boundary_rhorAUf, DF_REAL *ghf, DF_REAL *boundary_ghf,
                        DF_REAL *snGradRho, DF_REAL *boundary_snGradRho, DF_REAL *phig, DF_REAL *boundary_phig);

    void correct_pressure(DF_REAL *p_rgh, DF_REAL *boundary_p_rgh, DF_REAL *rho, DF_REAL *boundary_rho,
                          DF_REAL *gh, DF_REAL *boundary_gh, DF_REAL *p, DF_REAL *boundary_p, DF_REAL pRef);

    void constrain_pressure(DF_REAL *boundary_phiHbyA, DF_REAL *boundary_rho, DF_REAL *boundary_U,
                            DF_REAL *boundary_rhorAU, DF_REAL *d_boundary_snGradp, int *patch_type);

#ifdef USE_GRAPH
    // one graph for one eqn before using self-developed solver
    cudaGraph_t graph_pre, graph_post;
    cudaGraphExec_t graph_instance_pre, graph_instance_post;
    bool pre_graph_created = false;
    bool post_graph_created = false;
#endif
};

extern dfpEqn pEqn_GPU;

#endif //_DFPEQN_H