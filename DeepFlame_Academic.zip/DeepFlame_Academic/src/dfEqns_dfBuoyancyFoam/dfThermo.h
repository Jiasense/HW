
#ifndef _DFTHERMO_H
#define _DFTHERMO_H

#include "common.h"

#define GAS_CANSTANT 8314.46261815324
#define SQRT8 2.8284271247461903

class dfThermo
{
public:
    dfThermo() {}
    virtual ~dfThermo() {}

    DF_REAL *d_nasa_coeffs;
    DF_REAL *d_viscosity_coeffs;
    DF_REAL *d_thermal_conductivity_coeffs;
    DF_REAL *d_binary_diffusion_coeffs;
    DF_REAL *d_molecular_weights;
    DF_REAL *d_viscosity_conatant1;
    DF_REAL *d_viscosity_conatant2;
    DF_REAL *d_Hf298SS;

    DF_REAL *d_psip0;
    DF_REAL *d_boundary_psip0;

    // intermediate fields of correctThermo
    DF_REAL *d_mole_fraction;
    DF_REAL *d_mean_mole_weight;
    DF_REAL *d_T_poly;
    DF_REAL *d_species_viscosities;
    DF_REAL *d_species_thermal_conductivities;

    DF_REAL *d_boundary_mole_fraction;
    DF_REAL *d_boundary_mean_mole_weight;
    DF_REAL *d_boundary_T_poly;
    DF_REAL *d_boundary_species_viscosities;
    DF_REAL *d_boundary_species_thermal_conductivities;

    void updateRho();
    void psip0();
    void correctPsipRho();
    void correctThermo();

    void calculateEnergyGradient(int *patch_type, DF_REAL *T, DF_REAL *p, DF_REAL *y, DF_REAL *boundary_p, DF_REAL *boundary_y,
                                 DF_REAL *boundary_thermo_gradient = nullptr);
    void initStart();

protected:
    void init();

    void freeinit();

    void correctBCs();

    void updateMassFraction();

    void updateThermo();

    void updateThermoRho();

    void updateTPoly();

    void updatePsi();

    void updateViscosity();

    void updateThermoConductivity();

    void updateRhoD();

    void updateChemicalEnthalpy();

    void calculateHcGPU(int num_thread, DF_REAL *mass_fraction, DF_REAL *Hc);

    void calculateHsGPU(int num_thread, DF_REAL *he, DF_REAL *hc, DF_REAL *hs);

    void setPsip0(int num_thread, DF_REAL *p, DF_REAL *psi, DF_REAL *psip0);

    void addPsipRho(int num_thread, DF_REAL *p, DF_REAL *psi, DF_REAL *psip0, DF_REAL *rho);

    void calculateMassFractionGPU(int num_thread, DF_REAL *Y, DF_REAL *mole_fraction, DF_REAL *mean_mole_weight);

    void calculateRhoGPU(int num_thread, DF_REAL *p, DF_REAL *psi, DF_REAL *rho);

    void calculateTemperatureGPU(int num_thread, DF_REAL *T_init, DF_REAL *target_h, DF_REAL *T, DF_REAL *d_mass_fraction,
                                 DF_REAL atol = 1e-7, DF_REAL rtol = 1e-7, int max_iter = 20);

    void calculateThermoBoundaryGPU(int *patch_type, DF_REAL *T_init, DF_REAL *target_h, DF_REAL *T, DF_REAL *d_mass_fraction,
                                    DF_REAL atol = 1e-7, DF_REAL rtol = 1e-7, int max_iter = 20);

    void calculateTPolyGPU(int num_thread, DF_REAL *T, DF_REAL *T_poly);

    void calculatePsiGPU(int num_thread, DF_REAL *T, DF_REAL *mean_mole_weight, DF_REAL *d_psi);

    void calculateViscosityGPU(int num_thread, DF_REAL *T, DF_REAL *mole_fraction,
                               DF_REAL *T_poly, DF_REAL *species_viscosities, DF_REAL *viscosity);

    void calculateThermoConductivityGPU(int num_thread, DF_REAL *T, DF_REAL *T_poly, DF_REAL *d_y, DF_REAL *mole_fraction,
                                        DF_REAL *species_thermal_conductivities, DF_REAL *thermal_conductivity);

    void calculateRhoDGPU(int num_thread, DF_REAL *T, DF_REAL *T_poly, DF_REAL *p, DF_REAL *mole_fraction,
                          DF_REAL *mean_mole_weight, DF_REAL *rho, DF_REAL *rhoD);

    void calculate_phiAll(int *patch_type, DF_REAL *vf, DF_REAL *output, DF_REAL *boundary_vf = nullptr,
                          DF_REAL *boundary_output = nullptr, DF_REAL *boundary_grad = nullptr);

    void init_const_coeff_ptr(std::vector<std::vector<DF_REAL>> &nasa_coeffs, std::vector<std::vector<DF_REAL>> &viscosity_coeffs,
                              std::vector<std::vector<DF_REAL>> &thermal_conductivity_coeffs, std::vector<std::vector<DF_REAL>> &binary_diffusion_coeffs,
                              std::vector<DF_REAL> &molecular_weights);
};

extern dfThermo thermo_GPU;

#endif //_DFTHERMO_H