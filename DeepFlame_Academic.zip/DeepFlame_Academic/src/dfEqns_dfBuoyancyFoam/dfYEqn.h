#ifndef _DFYEQN_H
#define _DFYEQN_H

#include "solver.h"

class dfYEqn : public solver_d
{
public:
    dfYEqn() {}
    virtual ~dfYEqn() {}

    void process();

    DF_REAL *d_hai = nullptr;
    DF_REAL *d_grad_y = nullptr;
    DF_REAL *d_sumY_diff_error = nullptr;

    DF_REAL *d_boundary_hai = nullptr;
    DF_REAL *d_boundary_grad_y = nullptr;
    DF_REAL *d_boundary_sumY_diff_error = nullptr;

    void initStart();

protected:
    void setZeros();

    void init();

    void freeinit();

    void assembly(int s);

    void solve(int s);

    void correctBCs();

    void compute_keyVariables();

    void compute_inertIndex();

    void compute_RR();

    void compute_diff_alphaD();

    void compute_gradY();

    void compute_sumYDiffError_and_hDiffCorrFlux();

    void compute_convectionWeights();

#ifdef USE_GRAPH
    // one graph for one eqn before using self-developed solver
    cudaGraph_t graph_pre, graph_post;
    cudaGraphExec_t graph_instance_pre, graph_instance_post;
    bool pre_graph_created = false;
    bool post_graph_created = false;
#endif
};

extern dfYEqn YEqn_GPU;

#endif //_DFYEQN_H