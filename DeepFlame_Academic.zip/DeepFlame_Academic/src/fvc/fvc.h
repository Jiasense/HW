#include "common.h"

#ifndef _FVC_H
#define _FVC_H

namespace fvc
{
    // fvc_to_source_scalar
    void add_to_source_scalar(DF_REAL *fvc_output, DF_REAL *source, DF_REAL sign = 1.);

    void add_to_source_vector(DF_REAL *fvc_output, DF_REAL *source, DF_REAL sign = 1.);

    void ddt_scalar(DF_REAL *vf, DF_REAL *vf_old, DF_REAL *source, DF_REAL sign = 1.);

    void ddt_multiplyConst_scalar(DF_REAL *vf, DF_REAL *vf_old, DF_REAL *source, DF_REAL constValue, DF_REAL sign);

    void ddt_scalar_field(DF_REAL *vf, DF_REAL *vf_old, DF_REAL *source, DF_REAL sign = 1.);

    void ddt_vol_scalar_vol_scalar(DF_REAL *rho, DF_REAL *rho_old, DF_REAL *vf, DF_REAL *vf_old,
                                   DF_REAL *output, DF_REAL sign = 1.);

    void ddt_vol_scalar_vol_scalar_multiply_scalar(DF_REAL *rho, DF_REAL *rho_old,
                                                   DF_REAL *vf, DF_REAL *vf_old,
                                                   DF_REAL *field, DF_REAL *output, DF_REAL sign = 1.);

    void div_surface_scalar(DF_REAL *ssf, DF_REAL *boundary_ssf, DF_REAL *output, DF_REAL sign = 1.);

    void div_surface_scalar_field(DF_REAL *ssf, DF_REAL *boundary_ssf, DF_REAL *output, DF_REAL sign = 1.);

    void div_surface_scalar_vol_scalar(DF_REAL *vf, DF_REAL *ssf, DF_REAL *output,
                                       DF_REAL *boundary_vf, DF_REAL *boundary_ssf, DF_REAL sign = 1.,
                                       INTERPOLATION_SCHEME scheme = linear, int *patch_type = nullptr, 
                                       DF_REAL *refValue = nullptr, DF_REAL *snGrad = nullptr);

    void div_cell_vector(int *patch_type, DF_REAL *vf, DF_REAL *boundary_vf, DF_REAL *output, DF_REAL sign = 1.,
                         INTERPOLATION_SCHEME scheme = linear);

    void div_cell_tensor(int *patch_type, DF_REAL *vf, DF_REAL *boundary_vf, DF_REAL *output, DF_REAL sign = 1.,
                         INTERPOLATION_SCHEME scheme = linear);

    void grad_cell_scalar(int *patch_type, DF_REAL *vf, DF_REAL *boundary_vf,
                          DF_REAL *output, DF_REAL *boundary_output,
                          bool dividVol = false, bool correctBC = false, DF_REAL sign = 1.,
                          DF_REAL *refValue = nullptr, DF_REAL *snGrad = nullptr);

    void grad_cell_vector(int *patch_type, DF_REAL *vf, DF_REAL *boundary_vf,
                          DF_REAL *output, DF_REAL *boundary_output,
                          bool dividVol = false, bool correctBC = false, DF_REAL sign = 1.);

    // NOTICE: set num_species=1 for equations other than Y-eqn
    void laplacian_scalar(int num_species, int *patch_type,
                          DF_REAL *thermo_alpha, DF_REAL *hai, DF_REAL *vf, DF_REAL *output,
                          DF_REAL *boundary_thermo_alpha, DF_REAL *boundary_hai,
                          DF_REAL *boundary_vf, DF_REAL *boundary_output);

    void ddtCorr(int *patch_type, DF_REAL *phi_old, DF_REAL *u_old, DF_REAL *rho_old,
                 DF_REAL *boundary_phi_old, DF_REAL *boundary_u_old, DF_REAL *boundary_rho_old,
                 DF_REAL *output, DF_REAL *boundary_output);

    void flux_multiply_intepolate(int *patch_type, DF_REAL *field_vector, DF_REAL *boundary_field_vector,
                                  DF_REAL *vf, DF_REAL *boundary_vf, DF_REAL *output, DF_REAL *boundary_output);

    void flux_multi_scalar(int *patch_type, DF_REAL *field_vector, DF_REAL *boundary_field_vector,
                           DF_REAL *vf, DF_REAL *boundary_vf, DF_REAL *output, DF_REAL *boundary_output);

    void intepolate_multi_scalar(int *patch_type, DF_REAL *vf1, DF_REAL *vf2, DF_REAL *boundary_vf1, DF_REAL *boundary_vf2,
                                 DF_REAL *output, DF_REAL *boundary_output);

    void intepolate_scalar(int *patch_type, DF_REAL *vf, DF_REAL *boundary_vf, DF_REAL *output, DF_REAL *boundary_output, bool calcBou = true);

    void intepolate_maxscalar(int *patch_type, DF_REAL *vf, DF_REAL *boundary_vf, DF_REAL *output, DF_REAL *boundary_output, DF_REAL boundValue);

    void snGrad_scalar(int *patch_type, DF_REAL *vf, DF_REAL *boundary_vf, DF_REAL *output, DF_REAL *boundary_output, DF_REAL *boundary_grad = nullptr, bool calcBou = true);

    void reconstruct_scalar(int *patch_type, DF_REAL *ssf, DF_REAL *boundary_ssf, DF_REAL *output, DF_REAL *boundary_output, bool correctBC = false);
};

#endif //_FVC_H