#pragma once
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include <cuda_runtime.h>
#include "mpi.h"
#include "common.h"

void ncclInit(MPI_Comm mpi_comm, ncclComm_t &nccl_comm, ncclUniqueId &nccl_id,
              int *nRanks, int *myRank, int *localRank, int *mpi_init_flag);
