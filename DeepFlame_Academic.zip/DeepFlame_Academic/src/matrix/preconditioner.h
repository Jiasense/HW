/*******************************************************************************************
 * This file contains all the parameters and function declarations related to the 
 * preconditioner for matrix solving, which are implemented in preconditioner.cu.
 * 
 * @author Dang Guanlin
 ******************************************************************************************/

#ifndef _PRECONDITIONER_H
#define _PRECONDITIONER_H

#include "dfacademic.h"
#include "dfgamg.h"
#include "matrix_base.h"

#include "matrix_solution_scheme/CSR/dfCSRPreconditioner.h"
#include "matrix_solution_scheme/ELL/dfELLPreconditioner.h"


class preconditioner_d: public matrix_base_d
{
public:
    preconditioner_d() {}
    virtual ~preconditioner_d() {}

    preconditioner_d(matrix_base_d *matrix_set) : matrix_base_d(){}

    void set_preconditioner(CSRPreconditioner *&csr_gamg_preconditioner);
    void set_preconditioner(ELLPreconditioner *&ell_gamg_preconditioner);

};


#endif //_PRECONDITIONER_H