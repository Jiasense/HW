/*******************************************************************************************
 * This file contains all the parameters and function declarations related to the
 * matrix, which are implemented in matrix.cu.
 *
 * @author Dang Guanlin
 ******************************************************************************************/

#ifndef _MATRIX_H
#define _MATRIX_H

#ifndef __NVCC__
#include <rccl.h>
#else
#include <nccl.h>
#endif

#include "dfgamg.h"

typedef struct linearsolver_para_
{
    // AMGX
    int *d_ldu_to_csr = nullptr;
    int *d_csr_row_index = nullptr;
    int *d_csr_col_index = nullptr;

    // BiCGStab csr (device)
    int *d_ldu_to_csr_no_diag = nullptr;
    int *d_csr_row_index_no_diag = nullptr;
    int *d_csr_col_index_no_diag = nullptr;
    DF_REAL *d_off_diag_value = nullptr;

    // BiCGStab ell (device)
    int *d_ldu2ellIndex = nullptr;
    int ell_row_maxcount = 0;
    int *d_ellCols = nullptr;
    DF_REAL *d_ell_values = nullptr;

    // GAMG csr (host)
    int **h_ldu_to_csr_no_diag = nullptr;
    int **h_csr_row_index_no_diag = nullptr;
    int **h_csr_col_index_no_diag = nullptr;

    // GAMG ell (host)
    int **h_ldu2ellIndex = nullptr;
    int *h_ell_row_maxcount = nullptr;
    int **h_ellCols = nullptr;
} linearsolver_para;

typedef struct GAMGStruct_
{
    int nCell;
    int nFace;

    // === host data for multigpu parallel
    std::vector<int> nPatchFaces;

    // === device map data
    int *d_restrictMap = nullptr;
    int *d_faceRestrictMap = nullptr;
    int *d_faceFlipMap = nullptr; // bool2int

    // === device data for multigpu parallel
    int **d_faceCells = nullptr;
    int **d_patchFaceRestrictMap = nullptr;
    DF_REAL **d_interfaceBouCoeffs = nullptr;
    DF_REAL **d_interfaceIntCoeffs = nullptr;

    // === device ldu matrix data
    DF_REAL *d_lower = nullptr;
    DF_REAL *d_upper = nullptr;
    DF_REAL *d_diag = nullptr;
    int *d_lowerAddr = nullptr;
    int *d_upperAddr = nullptr;

    // === device csr matrix data
    int *d_ldu_to_csr_no_diag = nullptr;
    DF_REAL *d_off_diag_value = nullptr;
    int *d_csr_row_index_no_diag = nullptr;
    int *d_csr_col_index_no_diag = nullptr;

    // === device ell matrix data
    int *d_ldu2ellIndex = nullptr;
    int ell_row_maxcount = 0;
    int *d_ell_cols = nullptr;
    DF_REAL *d_ell_values = nullptr;

    // === device iteration data
    DF_REAL *d_CorrFields = nullptr; // solution for each level
    DF_REAL *d_Sources = nullptr;    // rhs for each level

    // === device temp data
    DF_REAL *d_AcfField = nullptr;           // for residual
    DF_REAL *d_preSmoothField = nullptr;     // for vCycle loop
    DF_REAL *d_scalingFactorNum = nullptr;   // for scale
    DF_REAL *d_scalingFactorDenom = nullptr; // for scale
    DF_REAL *d_bPrime = nullptr;             // for jacobi smoother
    DF_REAL *d_psiCopyPtr = nullptr;         // for jacobi smoother
} GAMGStruct;

class matrix_base_d
{
public:
    MATRIX_SMOOTHER smoother_choose;
    MATRIX_PRECONDITIONER preconditioner_choose;
    MATRIX_SOLVER solver_choose;
    MATRIX_SPARSE_FORMAT sparase_format_choose;
};

/*GAMG INFO*/
extern int agglomeration_level;
extern GAMG_control_para GAMG_configs;
extern GAMGStruct *GAMGdata;

extern linearsolver_para dataBase;

/** Solve matrix equation AX=b using linear solver:
 *  \param[in, out] psi             unknown value "X" [nCell]
 *  \param[in] source               rhs "b" of equation [nCell]
 *  \param[in] lower                lower coeff of "A" in ldu format [nFace]
 *  \param[in] upper                upper coeff of "A" in ldu format [nFace]
 *  \param[in] diag                 diag coeff of "A" in ldu format [nCell]
 *  \param[in] internalCoeffs       internal coefficients [nBoundarySurface]
 *  \param[in] boundaryCoeffs       boundary coefficients [nBoundarySurface]
 *  \param[in] equation             the enum for choosing equations, see "MATRIX_EQUATION" enum for more.
 */
void solve_matrix(DF_REAL *psi, DF_REAL *boundaryPsi, DF_REAL *source,
                  DF_REAL *lower, DF_REAL *upper, DF_REAL *diag,
                  DF_REAL *internalCoeffs, DF_REAL *boundaryCoeffs,
                  MATRIX_EQUATION equation);

/** ldu2csr:
 *  \param[in] num_surfaces             the num of surfaces
 *  \param[in] d_ldu_to_csr_no_diag     the map of ldu to csr
 *  \param[in] d_lower                  the lower array of ldu
 *  \param[in] d_upper                  the upper array of ldu
 *  \param[in, out] d_off_diag_value    the (no diag) value array of csr
 */
void ldu_to_csr(
    int num_surfaces,
    int *d_ldu_to_csr_no_diag,
    DF_REAL *d_lower,
    DF_REAL *d_upper,
    DF_REAL *d_off_diag_value);

/** ldu2ell:
 *  \param[in] num_surfaces             the num of surfaces
 *  \param[in] d_ldu2ellIndex           the map of ldu to ell
 *  \param[in] d_lower                  the lower array of ldu
 *  \param[in] d_upper                  the upper array of ldu
 *  \param[in, out] d_ell_values        the (no diag) value array of ell
 */
void ldu_to_ell(
    int num_surfaces,
    int *d_ldu2ellIndex,
    DF_REAL *d_lower,
    DF_REAL *d_upper,
    DF_REAL *d_ell_values);

void revert_ell(
    DF_REAL *ell_orig,
    int row_max_count,
    int nCells);

void AMGX_ldu_to_csr_scalar(int *ldu_to_csr_index, DF_REAL *ldu, DF_REAL *source, // b = source
                            const DF_REAL *internal_coeffs, const DF_REAL *boundary_coeffs, DF_REAL *A, DF_REAL *boundaryPsi, int *cyclicNeighbor);

//- Set solution in given cells to the specified values
//  and eliminate the corresponding equations from the matrix.
void manipulate_matrix(DF_REAL *psi, DF_REAL *source, DF_REAL *lower, DF_REAL *upper, DF_REAL *diag,
                       DF_REAL *internalCoeffs, DF_REAL *boundaryCoeffs, int *patch_type);

#endif //_MATRIX_H