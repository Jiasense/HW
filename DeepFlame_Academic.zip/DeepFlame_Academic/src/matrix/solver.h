/*******************************************************************************************
 * This file contains all the parameters and function declarations related to the 
 * solver for matrix solving, which are implemented in solver.cu.
 * 
 * @author Dang Guanlin
 ******************************************************************************************/

#ifndef _SOLVER_H
#define _SOLVER_H

#include "dfacademic.h"
#include "dfgamg.h"
#include "matrix_base.h"

#include "matrix_solution_scheme/CSR/dfCSRSolver.h"
#include "matrix_solution_scheme/ELL/dfELLSolver.h"


#include "AmgXSolver.h"


class solver_d: public matrix_base_d
{
public:
    solver_d() {};
    virtual ~solver_d() {}

    void set_solver(CSRSolver *&csr_solver);

    void set_solver(ELLSolver *&ell_solver);

    void set_solver(AmgXSolver *&amgx_solver, std::string settingPath=nullptr);

    CSRSolver *solver_CSR = nullptr;

    ELLSolver *solver_ELL = nullptr;  

    AmgXSolver *solver_AMGX = nullptr;  
    int num_iteration = 0;

    matrix_solver_para solver_paras;

    DF_REAL *d_source = nullptr;
    DF_REAL *d_lower = nullptr;
    DF_REAL *d_upper = nullptr;
    DF_REAL *d_diag = nullptr;
    DF_REAL *d_internalCoeffs = nullptr;
    DF_REAL *d_boundaryCoeffs = nullptr;

    DF_REAL *d_value_internal_coeffs = nullptr;
    DF_REAL *d_value_boundary_coeffs = nullptr;
    DF_REAL *d_gradient_internal_coeffs = nullptr;
    DF_REAL *d_gradient_boundary_coeffs = nullptr;
};


#endif //_SOLVER_H