/*******************************************************************************************
 * This file contains all the parameters and function declarations related to the 
 * smoother for matrix solving, which are implemented in smoothers.cu.
 * 
 * @author Dang Guanlin
 ******************************************************************************************/

#ifndef _SMOOTHER_H
#define _SMOOTHER_H

#include "dfacademic.h"
#include "dfgamg.h"
#include "matrix_base.h"

#include "matrix_solution_scheme/CSR/dfCSRSmoother.h"
#include "matrix_solution_scheme/ELL/dfELLSmoother.h"

class smoother_d: public matrix_base_d
{
public:
    smoother_d() {}
    virtual ~smoother_d() {}

    smoother_d(matrix_base_d *matrix_set) : matrix_base_d(){}

    void set_smoother(CSRSmoother *&csr_smoother);
    void set_smoother(ELLSmoother *&ell_smoother);

};


#endif //_SMOOTHER_H