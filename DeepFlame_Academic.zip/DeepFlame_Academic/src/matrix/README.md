# DeepFlame Linear Solver Library

DeepFlame linear solver is a GPU accelerated solver library.

Key features of the library include:
* Krylov methods: CG, BiCGSTAB, etc. with optional preconditioning
* Geometric algebraic multigrid (GAMG in OpenFOAM)
* Various smoother: Jacobi, SRJ, etc.
* Sparse formats: CSR, ELL, etc.

