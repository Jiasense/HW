#pragma once
#include "gamg.h"
#include "dfELLSmoother.h"
#include "smoother.h"

class ELLPreconditioner : public GAMG_base {

public:

    ELLPreconditioner(){}
    virtual ~ELLPreconditioner() {}

    smoother_d *smoother_d_ptr;

    virtual void initialize(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level) = 0;

    virtual void precondition
    (
        DF_REAL *wA,
        const DF_REAL *rA,
        const linearsolver_para& dataBase,
        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_
    ) = 0;

    virtual void fine2coarse(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) = 0;
    virtual void coarse2fine(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) = 0;
};

class GAMGELLPreconditioner : public ELLPreconditioner {
public:
    // variables related to the GAMG preconditioner
    int nLevels;

    ELLSmoother *smoother = nullptr;

    GAMGELLPreconditioner() {}
    virtual ~GAMGELLPreconditioner() {}

    virtual void initialize(
        /* init variables related to GAMG preconditioner */
        const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level
    ) override;

    virtual void precondition
    (
        DF_REAL *wA,
        const DF_REAL *rA,
        const linearsolver_para& dataBase,
        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_
    ) override;

    virtual void fine2coarse(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) override;
    virtual void coarse2fine(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) override;

};