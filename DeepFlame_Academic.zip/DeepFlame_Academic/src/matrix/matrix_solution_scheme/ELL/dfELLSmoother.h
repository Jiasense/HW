#pragma once
#include <cuda_runtime.h>
#include <vector>

#include "dfacademic.h"
#include "dfSolverOpBase.h"
#include "common.h"
#include "matrix_base.h"

class ELLSmoother
{

public:

    ELLSmoother(){}
    virtual ~ELLSmoother(){}

    virtual void smooth(
        cudaStream_t stream,
        int *neighbProcNo, 
        ncclComm_t nccl_comm,        
        int nSweeps,
        int nCells,
        DF_REAL* psi,
        DF_REAL* source,
        DF_REAL* psiCopyPtr,
        DF_REAL* bPrime,            
        int ell_row_maxcount,
        int* d_ell_cols, 
        DF_REAL* d_ell_values,
        DF_REAL* diagPtr,
        DF_REAL* scalarSendBufList_, 
        DF_REAL* scalarRecvBufList_,
        DF_REAL** interfaceBouCoeffs,
        int** faceCells, std::vector<int> nPatchFaces
    ) = 0;
};
    
class ELLJacobiSmoother : public ELLSmoother{
public:

    ELLJacobiSmoother(){}
    virtual ~ELLJacobiSmoother(){}

    virtual void smooth(
        cudaStream_t stream,
        int *neighbProcNo, 
        ncclComm_t nccl_comm,        
        int nSweeps,
        int nCells,
        DF_REAL* psi,
        DF_REAL* source,
        DF_REAL* psiCopyPtr,
        DF_REAL* bPrime,            
        int ell_row_maxcount,
        int* d_ell_cols, 
        DF_REAL* d_ell_values,
        DF_REAL* diagPtr,
        DF_REAL* scalarSendBufList_, 
        DF_REAL* scalarRecvBufList_,
        DF_REAL** interfaceBouCoeffs,
        int** faceCells, std::vector<int> nPatchFaces
    )override;
};

class ELLSRJSmoother : public ELLSmoother{
public:

    ELLSRJSmoother(){}
    virtual ~ELLSRJSmoother(){}

    std::vector<DF_REAL> omega = {1.73, 0.57};

    virtual void smooth(
        cudaStream_t stream,
        int *neighbProcNo, 
        ncclComm_t nccl_comm,        
        int nSweeps,
        int nCells,
        DF_REAL* psi,
        DF_REAL* source,
        DF_REAL* psiCopyPtr,
        DF_REAL* bPrime,            
        int ell_row_maxcount,
        int* d_ell_cols, 
        DF_REAL* d_ell_values,
        DF_REAL* diagPtr,
        DF_REAL* scalarSendBufList_, 
        DF_REAL* scalarRecvBufList_,
        DF_REAL** interfaceBouCoeffs,
        int** faceCells, std::vector<int> nPatchFaces
    )override;
};