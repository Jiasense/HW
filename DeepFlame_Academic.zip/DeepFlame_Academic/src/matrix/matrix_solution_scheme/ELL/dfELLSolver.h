#pragma once
#include "matrix_base.h"
#include "dfELLPreconditioner.h"
#include "dfSolverOpBase.h"
#include "preconditioner.h"

class ELLSolver {
protected:
    DF_REAL small_;
    DF_REAL vsmall_;
    int maxIter_;
    int minIter_;
    DF_REAL tolerance_;
    DF_REAL relTol_;
public:

    ELLSolver() : small_(1e-20), vsmall_(2.22507e-308), maxIter_(100), minIter_(0), tolerance_(1e-9), relTol_(0) {}
    virtual ~ELLSolver() {}

    preconditioner_d *preconditioner_d_ptr;

    ELLPreconditioner *precond_ = nullptr;

    virtual void initialize(const int, const size_t) = 0;

    virtual void initializeStream(const int, const size_t, cudaStream_t) = 0;

    virtual void freeInit() = 0;

    virtual void freeInitStream(cudaStream_t stream) = 0;

    virtual void setZero(const int nCells, const size_t boundary_surface_value_bytes) = 0;

    virtual bool checkSingularity(DF_REAL input){
        return (input < vsmall_);
    }

    virtual bool checkConvergence
    (
        DF_REAL finalResidual, 
        DF_REAL initialResidual,
        int nIterations
    )
    {
        if(
            finalResidual < tolerance_
            || (relTol_ > small_ * 1 && finalResidual < relTol_ * initialResidual)
        )
        {
            printf("GPU-ELL::solve end --------------------------------------------\n");
            printf("Initial residual = %.5e, Final residual = %.5e, No Iterations %d\n",initialResidual,finalResidual,nIterations);
            return true;
        }
        else{
            return false;
        }
    }

    virtual void solve
    (
        const linearsolver_para& dataBase,
        const DF_REAL* d_internal_coeffs,
        const DF_REAL* d_boundary_coeffs,
        int* patch_type,
        DF_REAL* diagPtr,
        DF_REAL* ellValues,
        int* ellCols,
        int ell_max_count,
        const DF_REAL *rhs, 
        DF_REAL *psi
    ) = 0;

    virtual void solve
    (
        DF_REAL* diagPtr,
        DF_REAL *rhs,
        DF_REAL *psi
    ) = 0;

    virtual void initSolvePerformance
    (
        DF_REAL small, 
        DF_REAL vsmall, 
        int maxIter, 
        int minIter, 
        DF_REAL tolerance, 
        DF_REAL relTol
    ){
        small_ = small;
        vsmall_ = vsmall;
        maxIter_ = maxIter;
        minIter_ = minIter;
        tolerance_ = tolerance;
        relTol_ = relTol;
    }
};

class PBiCGStabELLSolver : public ELLSolver {
public:
    DF_REAL *d_yA;
    DF_REAL *d_rA;
    DF_REAL *d_pA;
    DF_REAL *d_normFactors_tmp;
    DF_REAL *d_AyA;
    DF_REAL *d_sA;
    DF_REAL *d_zA;
    DF_REAL *d_tA;
    DF_REAL *d_rA0;
    DF_REAL *d_rA0rA_tmp;
    DF_REAL *d_rA0AyA_tmp;
    DF_REAL *d_tAtA_tmp;
    DF_REAL *d_sAtA_tmp;
    DF_REAL *reduce_result;
    DF_REAL *scalarSendBufList_;
    DF_REAL *scalarRecvBufList_;

    ELLPreconditioner *precond_ = nullptr;

    PBiCGStabELLSolver() {}
    virtual ~PBiCGStabELLSolver() {}

    virtual void initialize(const int nCells, const size_t boundary_surface_value_bytes) override;

    virtual void initializeStream(const int nCells, const size_t boundary_surface_value_bytes, cudaStream_t stream) override;

    void freeInit() override;

    virtual void freeInitStream(cudaStream_t stream) override;

    virtual void setZero(const int nCells, const size_t boundary_surface_value_bytes) override;

    virtual void solve
    (
        const linearsolver_para& dataBase,
        const DF_REAL* d_internal_coeffs,
        const DF_REAL* d_boundary_coeffs,
        int* patch_type,
        DF_REAL* diagPtr,
        DF_REAL* ellValues,
        int* ellCols,
        int ell_max_count,
        const DF_REAL *rhs, 
        DF_REAL *psi
    ) override;

    virtual void solve
    (
        DF_REAL* diagPtr,
        DF_REAL *rhs,
        DF_REAL *psi
    ) override {};
};

class PCGELLSolver : public ELLSolver {
public:
    // variables related to PCG solver
    DF_REAL *d_wA;
    DF_REAL *d_rA;
    DF_REAL *d_pA;
    DF_REAL *d_normFactors_tmp;
    DF_REAL *d_wArA_tmp;
    DF_REAL *d_wApA_tmp;
    
    DF_REAL *reduce_result;
    DF_REAL *scalarSendBufList_;
    DF_REAL *scalarRecvBufList_;

    // tmp
    ELLPreconditioner *precond_ = nullptr;

    PCGELLSolver() {}
    virtual ~PCGELLSolver() {}

    virtual void initialize(const int nCells, const size_t boundary_surface_value_bytes) override;

    virtual void initializeStream(const int nCells, const size_t boundary_surface_value_bytes, cudaStream_t stream) override;

    void freeInit() override;

    virtual void freeInitStream(cudaStream_t stream) override;

    virtual void setZero(const int nCells, const size_t boundary_surface_value_bytes) override;
    
    virtual void solve
    (
        const linearsolver_para& dataBase,
        const DF_REAL* d_internal_coeffs,
        const DF_REAL* d_boundary_coeffs,
        int* patch_type,
        DF_REAL* diagPtr,
        DF_REAL* ellValues,
        int* ellCols,
        int ell_max_count,
        const DF_REAL *rhs, 
        DF_REAL *psi
    ) override;

    virtual void solve
    (
        DF_REAL* diagPtr,
        DF_REAL *rhs,
        DF_REAL *psi
    ) override {};
};

class DiagonalELLSolver : public ELLSolver{
public:

    DiagonalELLSolver() {}
    virtual ~DiagonalELLSolver() {}

    // no use
    virtual void initialize(const int nCells, const size_t boundary_surface_value_bytes) override {};
    virtual void initializeStream(const int nCells, const size_t boundary_surface_value_bytes, cudaStream_t stream) override {};
    void freeInit() override {};
    virtual void freeInitStream(cudaStream_t stream) override {};
    virtual void setZero(const int nCells, const size_t boundary_surface_value_bytes) override {};
    virtual void solve
    (
        const linearsolver_para& dataBase,
        const DF_REAL* d_internal_coeffs,
        const DF_REAL* d_boundary_coeffs,
        int* patch_type,
        DF_REAL* diagPtr,
        DF_REAL* ellValues,
        int* ellCols,
        int ell_max_count,
        const DF_REAL *rhs, 
        DF_REAL *psi
    ) override {};

    virtual void solve
    (
        DF_REAL* diagPtr,
        DF_REAL *rhs,
        DF_REAL *psi
    ) override;
};