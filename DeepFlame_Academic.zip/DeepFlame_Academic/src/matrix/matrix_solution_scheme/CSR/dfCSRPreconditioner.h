#pragma once
#include "gamg.h"
#include "dfCSRSmoother.h"
#include "smoother.h"

class CSRPreconditioner : public GAMG_base {

public:

    CSRPreconditioner(){}
    virtual ~CSRPreconditioner() {}

    smoother_d *smoother_d_ptr;

    virtual void initialize(const linearsolver_para &dataBase, GAMGStruct *GAMGdata_, int agglomeration_level) = 0;

    virtual void precondition
    (
        DF_REAL *wA,
        const DF_REAL *rA,
        const linearsolver_para& dataBase,
        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_,
        DF_REAL *diag = nullptr,
        const DF_REAL *boundaryCoeffs = nullptr
    ) = 0;

    virtual void fine2coarse(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) = 0;
    virtual void coarse2fine(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) = 0;
};

class GAMGCSRPreconditioner : public CSRPreconditioner {
public:
    // variables related to the GAMG preconditioner
    int nLevels;

    CSRSmoother *smoother = nullptr;

    GAMGCSRPreconditioner() {}
    virtual ~GAMGCSRPreconditioner() {}

    virtual void initialize(
        /* init variables related to GAMG preconditioner */
        const linearsolver_para &dataBase, GAMGStruct *GAMGdata_, int agglomeration_level
    ) override;

    virtual void precondition
    (
        DF_REAL *wA,
        const DF_REAL *rA,
        const linearsolver_para& dataBase,
        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_,
        DF_REAL *diag = nullptr,
        const DF_REAL *boundaryCoeffs = nullptr
    ) override;

    virtual void fine2coarse(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) override;
    virtual void coarse2fine(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) override;
};

class DiagonalCSRPreconditioner : public CSRPreconditioner {
public:

    DiagonalCSRPreconditioner() {}
    virtual ~DiagonalCSRPreconditioner() {}

    virtual void initialize(
        /* init variables related to GAMG preconditioner */
        const linearsolver_para &dataBase, GAMGStruct *GAMGdata_, int agglomeration_level
    ) override {};

    virtual void precondition
    (
        DF_REAL *wA,
        const DF_REAL *rA,
        const linearsolver_para& dataBase,
        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_,
        DF_REAL *diag = nullptr,
        const DF_REAL *boundaryCoeffs = nullptr
    ) override;

    virtual void fine2coarse(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) override {};
    virtual void coarse2fine(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) override {};
};

class JacobiCSRPreconditioner : public CSRPreconditioner {
public:

    JacobiCSRPreconditioner() {}
    virtual ~JacobiCSRPreconditioner() {}

    virtual void initialize(
        /* init variables related to GAMG preconditioner */
        const linearsolver_para &dataBase, GAMGStruct *GAMGdata_, int agglomeration_level
    ) override {};

    virtual void precondition
    (
        DF_REAL *wA,
        const DF_REAL *rA,
        const linearsolver_para& dataBase,
        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_,
        DF_REAL *diag = nullptr,
        const DF_REAL *boundaryCoeffs = nullptr
    ) override;

    virtual void fine2coarse(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) override {};
    virtual void coarse2fine(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) override {};
};

