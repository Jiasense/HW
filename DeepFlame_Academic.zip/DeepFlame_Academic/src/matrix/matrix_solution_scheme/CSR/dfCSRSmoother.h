#pragma once
#include <cuda_runtime.h>
#include <vector>

#include "dfacademic.h"
#include "dfSolverOpBase.h"
#include "common.h"
#include "matrix_base.h"

class CSRSmoother
{

public:

    CSRSmoother(){}
    virtual ~CSRSmoother(){}

    virtual void smooth(
        cudaStream_t stream,
        int *neighbProcNo, 
        ncclComm_t nccl_comm,
        int nSweeps,
        int nCells,
        DF_REAL* psi,
        DF_REAL* source,
        DF_REAL* psiCopyPtr,
        DF_REAL* bPrime,            
        DF_REAL* off_diag_value_Ptr,
        int* off_diag_rowptr_Ptr, 
        int* off_diag_colidx_Ptr,
        DF_REAL* diagPtr,
        DF_REAL* scalarSendBufList_, 
        DF_REAL* scalarRecvBufList_,
        DF_REAL** interfaceBouCoeffs,
        int** faceCells, std::vector<int> nPatchFaces
    ) = 0;
};

class CSRJacobiSmoother : public CSRSmoother{
public:

    CSRJacobiSmoother(){}
    virtual ~CSRJacobiSmoother(){}

    virtual void smooth(
        cudaStream_t stream,
        int *neighbProcNo, 
        ncclComm_t nccl_comm,
        int nSweeps,
        int nCells,
        DF_REAL* psi,
        DF_REAL* source,
        DF_REAL* psiCopyPtr,
        DF_REAL* bPrime,            
        DF_REAL* off_diag_value_Ptr,
        int* off_diag_rowptr_Ptr, 
        int* off_diag_colidx_Ptr,
        DF_REAL* diagPtr,
        DF_REAL* scalarSendBufList_, 
        DF_REAL* scalarRecvBufList_,
        DF_REAL** interfaceBouCoeffs,
        int** faceCells, std::vector<int> nPatchFaces
    )override;
};

// Scheduled Relaxed Jacobi
class CSRSRJSmoother : public CSRSmoother{
public:

    CSRSRJSmoother(){}
    virtual ~CSRSRJSmoother(){}

    std::vector<DF_REAL> omega = {1.73, 0.57};

    virtual void smooth(
        cudaStream_t stream,
        int *neighbProcNo, 
        ncclComm_t nccl_comm,
        int nSweeps,
        int nCells,
        DF_REAL* psi,
        DF_REAL* source,
        DF_REAL* psiCopyPtr,
        DF_REAL* bPrime,            
        DF_REAL* off_diag_value_Ptr,
        int* off_diag_rowptr_Ptr, 
        int* off_diag_colidx_Ptr,
        DF_REAL* diagPtr,
        DF_REAL* scalarSendBufList_, 
        DF_REAL* scalarRecvBufList_,
        DF_REAL** interfaceBouCoeffs,
        int** faceCells, std::vector<int> nPatchFaces
    )override;
};