#pragma once
#include <cuda_runtime.h>
#include <vector>

#include "matrix_base.h"
#include "dfgamg.h"

using std::min;
using std::max;
using std::abs;

bool isPow2(int n);

void cal_tA_sA(
    cudaStream_t stream, int nCells, DF_REAL* d_tA,
    DF_REAL* d_tAtA_tmp, DF_REAL* d_sA, DF_REAL* d_sAtA_tmp);

void addInternalCoeffs(
        cudaStream_t stream, int num_patches, int *patch_size, 
        const DF_REAL *d_internal_coeffs, int *d_boundary_face_cell, 
        DF_REAL *diagPtr, int *patch_type);

void add_boundary_to_source
    (cudaStream_t stream, int num_patches, const int *patch_size, const int *patch_type, int *patch_offset,
    int *cyclicNeighbor, const int* boundary_cell_face, DF_REAL *source, const DF_REAL *boundary_coeffs, DF_REAL * boundary_psi);

void SpMV4CSR(
        cudaStream_t stream, const int nCells, DF_REAL *diagPtr, const DF_REAL *off_diag_value,
        int *d_csr_row_index_no_diag, int *d_csr_col_index_no_diag, DF_REAL *input, DF_REAL *output);

void SpMV4ELL(
        cudaStream_t stream, const int nCells, DF_REAL *diagPtr, DF_REAL *ellValues, 
        int *ellCols, int ell_max_count_, DF_REAL *input, DF_REAL *output);

void calrAandpA4CSR(
        cudaStream_t stream, const int nCells, DF_REAL *d_rA, const DF_REAL *rhs, DF_REAL *d_yA,
        DF_REAL *diagPtr, const DF_REAL *off_diag_value, int *d_csr_row_index_no_diag, DF_REAL *d_pA);

void calrAandpA4ELL(
        cudaStream_t stream, const int nCells, DF_REAL *d_rA, const DF_REAL *rhs, 
        DF_REAL *d_yA, DF_REAL *diagPtr, DF_REAL *ellValues, int ell_max_count_, DF_REAL *d_pA);

void subBoundaryCoeffs(
        cudaStream_t stream, int num_patches, int *patch_size, 
        const DF_REAL *d_boundary_coeffs, int *d_boundary_face_cell, 
        DF_REAL *d_pA, int *patch_type);

void calpAandnormFactor(
        cudaStream_t stream,int nCells, DF_REAL psi_ave, DF_REAL* pAPtr,
        DF_REAL* normFactor, DF_REAL* yAPtr, const DF_REAL* source);

void AmulBtoC(
        cudaStream_t stream, int nCells, DF_REAL *input1, DF_REAL *input2, DF_REAL *output);

void calpAandyAInit(
        cudaStream_t stream, int nCells, DF_REAL *d_pA, DF_REAL *d_rA, DF_REAL *d_yA);

void calsA(
    cudaStream_t stream, int nCells, DF_REAL *d_sA, 
    DF_REAL *d_rA, DF_REAL alpha, DF_REAL *d_AyA);

void calpAandyA(
        cudaStream_t stream, int nCells, DF_REAL *d_pA, DF_REAL *d_rA,
        DF_REAL beta, DF_REAL omega, DF_REAL *d_AyA, DF_REAL *d_yA);

void exitLoop(
        cudaStream_t stream, int nCells, DF_REAL input1, DF_REAL *input2, DF_REAL* output);

void AmulAtoB(
    cudaStream_t stream, int nCells, DF_REAL *input, DF_REAL* output);

void calpsiandrA(
    cudaStream_t stream, int nCells, DF_REAL *psi, DF_REAL *d_yA, DF_REAL *d_zA, 
    DF_REAL *d_rA, DF_REAL *d_sA, DF_REAL *d_tA, DF_REAL alpha, DF_REAL omega);

void updateMatrixInterfaces(
    cudaStream_t stream, int num_patches, int *patch_size,
    int *neighbProcNo,  ncclComm_t nccl_comm,
    int *interfaceFlag, DF_REAL *input, DF_REAL *output, 
    DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_,
    const DF_REAL *d_boundary_coeffs, int *d_boundary_face_cell, int *patch_type, DF_REAL sign = 1.0
);

// PCG
void calpA(
    cudaStream_t stream, int nCells, DF_REAL* pAPtr, DF_REAL* wAPtr, DF_REAL beta
);

void calpsiandrA(
    cudaStream_t stream,  int nCells, DF_REAL* psi, DF_REAL* pA, DF_REAL* rA, DF_REAL* wA, DF_REAL alpha
);

void reduce(int size, int threads, int blocks, DF_REAL *d_idata, DF_REAL *d_odata, cudaStream_t stream, const bool isabs);

void addInternalInterfaceCoeffs(
            cudaStream_t stream, std::vector<int> patchSize, 
            DF_REAL **interfaceIntCoeffs, int **boundaryFaceCell, DF_REAL *diag);
            
void updateMatrixInterfaceCoeffs(
        cudaStream_t stream, int *neighbProcNo,  ncclComm_t nccl_comm,
        std::vector<int> patchSize, DF_REAL *input, DF_REAL *output, 
        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_,
        DF_REAL **interfaceBouCoeffs, int **boundaryFaceCell, DF_REAL sign = 1.);

// Diagonal
void solveDiagonalMatrix(
        cudaStream_t stream, int nCells, DF_REAL* diagPtr, const DF_REAL* rhs, DF_REAL* psi
);

// ** --- New kernel (merge) --- **

void merge_1(
        cudaStream_t stream, const int nCells, DF_REAL *diagPtr, const DF_REAL *off_diag_value,
        int *d_csr_row_index_no_diag, int *d_csr_col_index_no_diag, DF_REAL *input, DF_REAL *output, DF_REAL *pA);

void merge_2(
    cudaStream_t stream, int nCells, DF_REAL *d_pA, DF_REAL *d_rA,
    DF_REAL beta, DF_REAL omega, DF_REAL *d_AyA, DF_REAL *d_yA, DF_REAL *diagPtr, 
    const DF_REAL *off_diag_value, int *d_csr_row_index_no_diag, 
    int *d_csr_col_index_no_diag, DF_REAL *output);

void merge_3(
    cudaStream_t stream, const int nCells, DF_REAL *diagPtr, const DF_REAL *off_diag_value,
    int *d_csr_row_index_no_diag, int *d_csr_col_index_no_diag, DF_REAL *input, DF_REAL *output, DF_REAL *zAPtr);

void merge_1_ell(
        cudaStream_t stream, const int nCells, DF_REAL *diagPtr, DF_REAL* ellValues,
        int* ellCols, int ell_max_count_, DF_REAL *input, DF_REAL *output, DF_REAL *pA);

void merge_2_ell(
    cudaStream_t stream, int nCells, DF_REAL *d_pA, DF_REAL *d_rA,
    DF_REAL beta, DF_REAL omega, DF_REAL *d_AyA, DF_REAL *d_yA, DF_REAL *diagPtr, 
    DF_REAL* ellValues,
    int* ellCols,
    int ell_max_count_, DF_REAL *output
);

void merge_3_ell(
    cudaStream_t stream, const int nCells, DF_REAL *diagPtr, DF_REAL* ellValues,
    int* ellCols, int ell_max_count_, DF_REAL *input, DF_REAL *output, DF_REAL *zAPtr);

void split_1(
    cudaStream_t stream, const int nCells, DF_REAL *d_rA, const DF_REAL *rhs, DF_REAL *d_yA, DF_REAL* d_rA0);