/*******************************************************************************************
 * This file contains all the parameters and function declarations related to the 
 * GAMG, which are implemented in gamg.cu and gamg_kernel.cu.
 * 
 * @author Dang Guanlin, Bai Xuan
 ******************************************************************************************/

#ifndef _GAMG_H
#define _GAMG_H

#include "common.h"
#include "matrix_base.h"
#include "dfSolverOpBase.h"

class GAMG_base
{
public:
    GAMG_base(){}
    virtual ~GAMG_base() {}

    /* Malloc GAMG data for each level. */ 
    void initializeBase(GAMGStruct *GAMGdata_, int agglomeration_level);

    /* Free GAMG data for each level. */ 
    void freeInitializeBase(GAMGStruct *GAMGdata_, int agglomeration_level);

    /* Set ldu matrix & coeff for leveli=0, and memset=0 other levels. */ 
    void initMatrixData(const linearsolver_para& dataBase, GAMGStruct *GAMGdata, int agglomeration_level, 
                        DF_REAL *lower, DF_REAL *upper, DF_REAL *diag, 
                        DF_REAL *internalCoeffs, DF_REAL *boundaryCoeffs);                 

    /* Get interface coeff from all boundary coeff. */ 
    void getInterfacesCoeffs(cudaStream_t stream, int num_patches, int *patch_size, 
                            const int *interfaceFlag, 
                            DF_REAL *d_boundary_coeffs, DF_REAL *d_internal_coeffs, 
                            DF_REAL **d_interfaceBouCoeffs, DF_REAL **d_interfaceIntCoeffs);   

    /* Restrict ldu matrix & coeff other than leveli=0. */                         
    void agglomerateMatrix(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level);
    
    /* Set Corr & Source =0 for each level. */  
    void initCycle(GAMGStruct *GAMGdata_, int agglomeration_level);

    /* Multigrid Vcycle loop. */  
    void Vcycle(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_);
    
    /* Multigrid Wcycle loop. */  
    void Wcycle(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_);
    
    /* Multigrid Fcycle loop. */ 
    void Fcycle(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_);
    
    /* Direct solve for the coarest level, only support nCellsInCoarsestLevel=1 or =4 now. */
    void directSolveCoarsest(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level);

    /* Loop from finear startLevel to coarser endLevel, implemented in CSR & ELL. */
    virtual void fine2coarse(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) = 0;
    
    /* Loop from coarser startLevel to finer endLevel, implemented in CSR & ELL. */                    
    virtual void coarse2fine(const linearsolver_para& dataBase, GAMGStruct *GAMGdata_, int agglomeration_level, 
                        int startLevel, int endLevel, DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_) = 0;

    /********************************************************************************************/ 
    /******************************** MODULES FOR GAMG LOOP *************************************/
    /********************************************************************************************/
    /* Restrict module: used in fine2coarse, get coarser field from finer field. */
    void restrictFieldGPU(cudaStream_t stream, int nFineCells, int* d_restrictMap, 
                            DF_REAL* d_fineField, DF_REAL* d_coarseField);

    /* Restrict matrix module: used in initMatrixData, get coarser matrix from finer matrix. */                            
    void restrictMatrixGPU(cudaStream_t stream, int nFineFaces, int* d_faceRestrictMap, int* d_faceFlipMap,
                            DF_REAL* d_fineUpper, DF_REAL* d_fineLower, 
                            DF_REAL* d_coarseUpper, DF_REAL* d_coarseLower, DF_REAL* d_coarseDiag);

    /* Prolong module: used in coarse2fine, get finer field from coarser field. */   
    void prolongFieldGPU(cudaStream_t stream, int nFineCells, int* d_restrictMap, 
                            DF_REAL* d_fineField, DF_REAL* d_coarseField);

    /* updateCorr module: used in coarse2fine, add corrField to preSmoothField. */ 
    void updateCorrFieldGPU(cudaStream_t stream, int nCells, 
                            DF_REAL* d_Field, DF_REAL* d_preSmoothField);

    /* directSolve1x1 module: used in directSolveCoarsest, direct solve for nCellsInCoarsestLevel=1. */ 
    void directSolve1x1GPU(cudaStream_t stream, 
                            DF_REAL* d_diag, DF_REAL* d_corrField, DF_REAL* d_sourceField);

    /* directSolve4x4 module: used in directSolveCoarsest, direct solve for nCellsInCoarsestLevel=4. */                             
    void directSolve4x4GPU(cudaStream_t stream, 
                            DF_REAL* d_diag, DF_REAL* d_upper, DF_REAL* d_lower, 
                            DF_REAL* d_corrField, DF_REAL* d_sourceField);

    /********************************************************************************************/
    /******************************** MODULES FOR CSR FORMAT ************************************/
    /********************************************************************************************/
    /* CSR scale module: used in fine2coarse & coarse2fine, correct error from restrict, use this if(matrix.symmetric()). */ 
    void scaleFieldGPU( cudaStream_t stream, int *neighbProcNo, ncclComm_t nccl_comm,int nCells, 
                        DF_REAL* d_Field, DF_REAL* d_Source, DF_REAL* d_AcfField, 
                        DF_REAL* diag, DF_REAL* off_diag_value,
                        int* csr_row_index_no_diag, int* csr_col_index_no_diag, 
                        DF_REAL** interfaceIntCoeffs, DF_REAL** interfaceBouCoeffs,
                        int** faceCells, std::vector<int> nPatchFaces, 
                        DF_REAL* d_scalingFactorNum, DF_REAL* d_scalingFactorDenom,
                        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_ );

    /* CSR updateSource module: used in fine2coarse, calculate residual and set source for next level. */ 
    void updateSourceFieldGPU(cudaStream_t stream, int *neighbProcNo, ncclComm_t nccl_comm, int nCells, 
                            DF_REAL* d_Sources, DF_REAL* d_AcfField, DF_REAL* d_CorrFields,
                            DF_REAL* diag, DF_REAL* off_diag_value,
                            int* csr_row_index_no_diag, int* csr_col_index_no_diag, 
                            DF_REAL** interfaceIntCoeffs, DF_REAL** interfaceBouCoeffs,
                            int** faceCells, std::vector<int> nPatchFaces,
                            DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_);

    /* CSR interpolate module: used in coarse2fine, correct error from prolong. */                         
    void interpolateFieldGPU(cudaStream_t stream, int *neighbProcNo, ncclComm_t nccl_comm, int nCells, int nCCells, 
                        DF_REAL* psi, DF_REAL* Apsi, 
                        DF_REAL* diag, DF_REAL* off_diag_value,
                        int* csr_row_index_no_diag, int* csr_col_index_no_diag,  
                        DF_REAL** interfaceIntCoeffs, DF_REAL** interfaceBouCoeffs, 
                        int** faceCells, std::vector<int> nPatchFaces,
                        int* restrictAddressing, DF_REAL* psiC,
                        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_);   
                        
    /* CSR Amul module:  calculate matrix multiplication result = input*A . */ 
    void AmulGPU(cudaStream_t stream, int *neighbProcNo, ncclComm_t nccl_comm, DF_REAL* result, DF_REAL* input,
                DF_REAL* diag, DF_REAL* off_diag_value,
                int* csr_row_index_no_diag, int* csr_col_index_no_diag, 
                DF_REAL** interfaceIntCoeffs, DF_REAL** interfaceBouCoeffs,
                int** faceCells, std::vector<int> nPatchFaces, int nCells,
                DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_);     

    /********************************************************************************************/
    /******************************** MODULES FOR ELL FORMAT ************************************/
    /********************************************************************************************/
    /* ELL scale module: used in fine2coarse & coarse2fine, correct error from restrict, use this if(matrix.symmetric()). */ 
    void scaleFieldGPU_ell( cudaStream_t stream, int *neighbProcNo, ncclComm_t nccl_comm, int nCells, 
                        DF_REAL* d_Field, DF_REAL* d_Source, DF_REAL* d_AcfField, 
                        DF_REAL* diag, int ell_row_maxcount,
                        int* d_ell_cols, DF_REAL* d_ell_values, 
                        DF_REAL** interfaceIntCoeffs, DF_REAL** interfaceBouCoeffs,
                        int** faceCells, std::vector<int> nPatchFaces, 
                        DF_REAL* d_scalingFactorNum, DF_REAL* d_scalingFactorDenom,
                        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_ );

    /* ELL updateSource module: used in fine2coarse, calculate residual and set source for next level. */ 
    void updateSourceFieldGPU_ell(cudaStream_t stream, int *neighbProcNo, ncclComm_t nccl_comm, int nCells, 
                            DF_REAL* d_Sources, DF_REAL* d_AcfField, DF_REAL* d_CorrFields,
                            DF_REAL* diag, int ell_row_maxcount,
                            int* d_ell_cols, DF_REAL* d_ell_values,
                            DF_REAL** interfaceIntCoeffs, DF_REAL** interfaceBouCoeffs,
                            int** faceCells, std::vector<int> nPatchFaces,
                            DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_);

    /* ELL interpolate module: used in coarse2fine, correct error from prolong. */   
    void interpolateFieldGPU_ell(cudaStream_t stream, int *neighbProcNo, ncclComm_t nccl_comm, int nCells, int nCCells, 
                        DF_REAL* psi, DF_REAL* Apsi, 
                        DF_REAL* diag, int ell_row_maxcount,
                        int* d_ell_cols, DF_REAL* d_ell_values,
                        DF_REAL** interfaceIntCoeffs, DF_REAL** interfaceBouCoeffs, 
                        int** faceCells, std::vector<int> nPatchFaces,
                        int* restrictAddressing, DF_REAL* psiC,
                        DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_); 

    /* ELL Amul module:  calculate matrix multiplication result = input*A . */ 
    void AmulGPU_ell(cudaStream_t stream, int *neighbProcNo, ncclComm_t nccl_comm, DF_REAL* result, DF_REAL* input,
                DF_REAL* diag, int ell_row_maxcount,
                int* d_ell_cols, DF_REAL* d_ell_values, 
                DF_REAL** interfaceIntCoeffs, DF_REAL** interfaceBouCoeffs,
                int** faceCells, std::vector<int> nPatchFaces, int nCells,
                DF_REAL *scalarSendBufList_, DF_REAL *scalarRecvBufList_);
                  
};

#endif //_GAMG_H