/*******************************************************************************************
 * This file contains declarations of generic helper functions and implementations of
 * helper macros.
 *
 * @author Dang Guanlin
 ******************************************************************************************/

#ifndef _COMMON_H
#define _COMMON_H

#include <sys/time.h>
#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <iomanip> 

#include <cuda.h>
#include <cuda_runtime.h>
#include <cuda_runtime_api.h>

#define blockDim_global 1024

#define checkCudaErrors(val) check((val), #val, __FILE__, __LINE__)

#ifndef __NVCC__
#include <rccl.h>

#define MALLOC_ASYNC(src, size, stream) \
checkCudaErrors(hipMallocAsync((void **)&src, size, stream));\
checkCudaErrors(hipMemsetAsync(src, 0, size, stream));

#define FREE_ASYNC(src, stream) \
hipFreeAsync(src, stream)

#else
#include <nccl.h>
#include <nvtx3/nvToolsExt.h>

#define MALLOC_ASYNC(src, size, stream) \
checkCudaErrors(cudaMallocAsync((void **)&src, size, stream));\
checkCudaErrors(cudaMemsetAsync(src, 0, size, stream));


#define FREE_ASYNC(src, stream) \
cudaFreeAsync(src, stream)

#endif

// #define USE_GRAPH
#define STREAM_ALLOCATOR

#include "dfacademic.h"

/*CUDA INFO*/
extern dim3 boundaryBlockDim;
extern dim3 boundaryGridDim;

extern size_t cellThreadsPerBlock;
extern size_t cellBlocksPerGrid;

extern size_t surfaceThreadsPerBlock;
extern size_t surfaceBlocksPerGrid;

extern size_t bouSurfThreadsPerBlock;
extern size_t bouSurfBlocksPerGrid;

const DF_REAL SMALL = std::numeric_limits<DF_REAL>::epsilon();
extern bool masterRank;

/** An enumeration for set boundary conditions.
 */
enum boundaryConditions
{
    zeroGradient,           // zeroGradient boundary condition
    fixedValue,             // fixedValue boundary condition
    coupled,                // coupled boundary condition
    empty,                  // empty boundary condition
    gradientEnergy,         // gradientEnergy boundary condition
    calculated,             // calculated boundary condition
    cyclic,                 // cyclic boundary condition
    processor,              // processor boundary condition
    extrapolated,           // extrapolated boundary condition
    fixedEnergy,            // fixedEnergy boundary condition
    processorCyclic,        // processorCyclic boundary condition
    pressureInletOutlet,    // pressureInletOutlet boundary condition
    totalPressure,          // totalPressure boundary condition
    wedge,
    noSlip,
    turbulentMixingLengthDissipationRateInlet,
    turbulentIntensityKineticEnergyInlet,
    nutkWallFunction,
    epsilonWallFunction,
    kqRWallFunction,
    alphatWallFunction,
    mapped,                 // correct BC on cpu
    inletOutlet,
    totalFlowRateAdvectiveDiffusive,
    prghTotalHydrostaticPressure,
    fixedFluxPressure,
    flowRateInletVelocity,
    fixedGradient,
    mixedEnergy,
    decayingTurbulenceInflowGeneratorMod_ZY 
};

typedef struct data_para_
{
    DF_REAL rDeltaT = 0;
    DF_REAL p0 = 0;            // totalPressure BC setting
    DF_REAL pRef = 0;
    DF_REAL aveU = 0.0;
    DF_REAL massFlowRate = 0.0;
    int num_species = 0;
    int inertIndex = -1;

    int localRank = 0;
    cudaStream_t stream;
    ncclComm_t nccl_comm;

    int *patch_type = nullptr; // tmp: for linear solver, only processor type used
    int *patch_type_U = nullptr;  // tmp: for flowRateInletVelocity BC reduce
    
    int *d_patch_type_rho = nullptr;
    int *d_patch_type_U = nullptr;
    int *d_patch_type_Y = nullptr;
    int *d_patch_type_p = nullptr;
    int *d_patch_type_p_rgh = nullptr;
    int *d_patch_type_he = nullptr;
    int *d_patch_type_k = nullptr;
    int *d_patch_type_T = nullptr;
    int *d_patch_type_calculated = nullptr;
    int *d_patch_type_extropolated = nullptr;
    DF_REAL *d_patch_refValue_Y =  nullptr;
    DF_REAL *d_patch_refValue_T =  nullptr;

    DF_REAL *d_phi = nullptr;
    DF_REAL *d_rho = nullptr;
    DF_REAL *d_u = nullptr;
    DF_REAL *d_y = nullptr;
    DF_REAL *d_p = nullptr;
    DF_REAL *d_p_rgh = nullptr;
    DF_REAL *d_ph_rgh = nullptr;
    DF_REAL *d_gh = nullptr;
    DF_REAL *d_ghf = nullptr;

    DF_REAL *d_k = nullptr;
    DF_REAL *d_he = nullptr;
    DF_REAL *d_T = nullptr;
    DF_REAL *d_mu = nullptr;
    DF_REAL *d_dpdt = nullptr;
    DF_REAL *d_thermo_alpha = nullptr;
    DF_REAL *d_thermo_rhoD = nullptr;
    DF_REAL *d_thermo_psi = nullptr;
    DF_REAL *d_thermo_rho = nullptr;
    DF_REAL *d_alphaEff = nullptr;

    DF_REAL *d_boundary_phi = nullptr;
    DF_REAL *d_boundary_rho = nullptr;
    DF_REAL *d_boundary_u = nullptr;
    DF_REAL *d_boundary_y = nullptr;
    DF_REAL *d_boundary_p = nullptr;
    DF_REAL *d_boundary_p_rgh = nullptr;
    DF_REAL *d_boundary_ph_rgh = nullptr;
    DF_REAL *d_boundary_gh = nullptr;
    DF_REAL *d_boundary_ghf = nullptr;
    DF_REAL *d_boundary_k = nullptr;
    DF_REAL *d_boundary_he = nullptr;
    DF_REAL *d_boundary_T = nullptr;
    DF_REAL *d_boundary_mu = nullptr;
    DF_REAL *d_boundary_thermo_alpha = nullptr;
    DF_REAL *d_boundary_thermo_rhoD = nullptr;    
    DF_REAL *d_boundary_thermo_psi = nullptr;
    DF_REAL *d_boundary_thermo_rho = nullptr;
    DF_REAL *d_boundary_alphaEff = nullptr;
    DF_REAL *d_boundary_snGradp = nullptr;
    DF_REAL *d_boundary_snGradhe = nullptr;

    // pre-timestep variables
    DF_REAL *d_rho_old = nullptr;
    DF_REAL *d_k_old = nullptr;
    DF_REAL *d_u_old = nullptr;
    DF_REAL *d_p_old = nullptr;
    DF_REAL *d_phi_old = nullptr;    
    DF_REAL *d_thermo_psi_old = nullptr;
    DF_REAL *d_he_old = nullptr;
    DF_REAL *d_y_old = nullptr;
    DF_REAL *d_p_rgh_old = nullptr;

    DF_REAL *d_boundary_phi_old = nullptr;
    DF_REAL *d_boundary_rho_old = nullptr;
    DF_REAL *d_boundary_u_old = nullptr;
    DF_REAL *d_boundary_p_old = nullptr;

    // internal fields used between eqns
    DF_REAL *d_rAU = nullptr;
    DF_REAL *d_HbyA = nullptr;
    DF_REAL *d_diff_alphaD = nullptr;
    DF_REAL *d_hDiff_corr_flux = nullptr;
    DF_REAL *d_RR = nullptr;

    // boundary fields used between eqns
    DF_REAL *d_boundary_rAU = nullptr;
    DF_REAL *d_boundary_HbyA = nullptr;
    DF_REAL *d_boundary_diff_alphaD = nullptr;
    DF_REAL *d_boundary_hDiff_corr_flux = nullptr;

    // coeffs for UEqn getHbyA()
    DF_REAL *d_source_ueqn = nullptr;
    DF_REAL *d_lower_ueqn = nullptr;
    DF_REAL *d_upper_ueqn = nullptr;
    DF_REAL *d_internalCoeffs_ueqn = nullptr;
    DF_REAL *d_boundaryCoeffs_ueqn = nullptr;

    DF_REAL *d_hc = nullptr;
    DF_REAL *d_hs = nullptr;
    DF_REAL *d_HRR = nullptr;
    DF_REAL *d_phiHc = nullptr;
    DF_REAL *d_phiHs = nullptr;
    DF_REAL *d_phiH = nullptr;
} data_para;
extern data_para dfDataBase;

typedef struct mesh_para_
{
    /* constant values */
    int num_cells = 0;
    int num_total_cells = 0;
    int num_surfaces = 0;
    int num_boundary_surfaces = 0;
    int num_proc_surfaces = 0;
    int num_patches = 0;
    int num_Nz = 0;

    int *d_lowerAddr;
    int *d_upperAddr;

    DF_REAL *d_volume = nullptr;
    DF_REAL *d_sf = nullptr;
    DF_REAL *d_mag_sf = nullptr;
    DF_REAL *d_mesh_dis = nullptr;
    DF_REAL *d_delta_coeffs = nullptr;

    DF_REAL *d_weight  = nullptr;
    DF_REAL *d_convectWeight = nullptr;
    DF_REAL *d_schemesWeight = nullptr;

    /* boundary variables */
    int *patch_size;   
    int *patch_offset; 
    int *neighbProcNo; 
    int *interfaceFlag;
    int *cyclicNeighbor;

    int *d_patch_size;
    int *d_patch_offset;
    int *d_patch_start; 
    int *d_cyclicNeighbor;

    int *d_boundary_face_cell;
    int *d_cell2face;
    int *d_face2patch;

    DF_REAL *d_boundary_sf = nullptr;
    DF_REAL *d_boundary_mag_sf = nullptr;
    DF_REAL *d_boundary_delta_coeffs = nullptr; 
    DF_REAL *d_boundary_weight  = nullptr;
    DF_REAL *d_boundary_weight_delta  = nullptr;
    DF_REAL *d_boundary_convectWeight = nullptr;
    DF_REAL *d_boundary_schemesWeight = nullptr;

    // for wedge boundary type
    DF_REAL *d_faceT = nullptr; // face transformation tensor: [num_patches*9]
    DF_REAL *d_cellT = nullptr; // neighbour-cell transformation tensor: [num_patches*9]
} mesh_para;
extern mesh_para meshBase;
extern int maxPatchSize;

extern fvSchemes_para schemes;
extern bool compareCPUResults;

#define checkMpiErrors(cmd)                          \
    do                                               \
    {                                                \
        int e = cmd;                                 \
        if (e != MPI_SUCCESS)                        \
        {                                            \
            printf("Failed: MPI error %s:%d '%d'\n", \
                   __FILE__, __LINE__, e);           \
            exit(EXIT_FAILURE);                      \
        }                                            \
    } while (0)

#define checkNcclErrors(cmd)                                   \
    do                                                         \
    {                                                          \
        ncclResult_t r = cmd;                                  \
        if (r != ncclSuccess)                                  \
        {                                                      \
            printf("Failed, NCCL error %s:%d '%s'\n",          \
                   __FILE__, __LINE__, ncclGetErrorString(r)); \
            exit(EXIT_FAILURE);                                \
        }                                                      \
    } while (0)

static const char *_cudaGetErrorEnum(cudaError_t error)
{
    return cudaGetErrorName(error);
}

template <typename T>
void check(T result, char const *const func, const char *const file, int const line)
{
    if (result)
    {
        fprintf(stderr, "cuda error at %s:%d code=%d(%s) \"%s\" \n", file, line,
                static_cast<unsigned int>(result), _cudaGetErrorEnum(result), func);
        exit(EXIT_FAILURE);
    }
}

void writeDoubleArrayToFile(DF_REAL* data_d, int num, const std::string& filename); 
void syncStream();

/** Calculate interpolation weight based on the user-defined interpolating schemes.
 *
 * \param[out] weight               Interpolation weights [nFace]
 * \param[out] boundary_weight      Interpolation boundary weights [nBoundarySurface]
 * \param[in] scheme                Enum for choosing interpolation schemes, see "INTERPOLATION_SCHEME" enum for more details.
 */
void compute_weight(INTERPOLATION_SCHEME scheme, DF_REAL *weight,
                    DF_REAL *boundary_weight = nullptr, DF_REAL *vf = nullptr, DF_REAL *boundary_vf = nullptr,
                    DF_REAL *grad_vf = nullptr, DF_REAL *boundary_grad_vf = nullptr, int nVariate = 1);

#endif //_COMMON_H