#ifndef _INTERPOLATION_H
#define _INTERPOLATION_H

#include "dfacademic.h"
#include "common.h"

class Interpolation_base
{
public:
    Interpolation_base() {};
    virtual ~Interpolation_base() {};

    virtual void interpolate(DF_REAL *weight, DF_REAL *boundary_weight = nullptr, DF_REAL *vf = nullptr, DF_REAL *boundary_vf = nullptr,
                             DF_REAL *grad_vf = nullptr, DF_REAL *boundary_grad_vf = nullptr, int nVariate = 0, bool limited01 = false) = 0;
};

class Interpolation_linear : public Interpolation_base
{
public:
    Interpolation_linear() {};
    virtual ~Interpolation_linear() {};

    void interpolate(DF_REAL *weight, DF_REAL *boundary_weight = nullptr, DF_REAL *vf = nullptr, DF_REAL *boundary_vf = nullptr,
                     DF_REAL *grad_vf = nullptr, DF_REAL *boundary_grad_vf = nullptr, int nVariate = 0, bool limited01 = false)
    {
        checkCudaErrors(cudaMemcpyAsync(weight, meshBase.d_weight, sizeof(DF_REAL) * meshBase.num_surfaces, cudaMemcpyDeviceToDevice, dfDataBase.stream));
        checkCudaErrors(cudaMemcpyAsync(boundary_weight, meshBase.d_boundary_weight, sizeof(DF_REAL) * meshBase.num_boundary_surfaces, cudaMemcpyDeviceToDevice, dfDataBase.stream));
    };
};

class Interpolation_upwind : public Interpolation_base
{
public:
    Interpolation_upwind() {};
    virtual ~Interpolation_upwind() {};

    void interpolate(DF_REAL *weight, DF_REAL *boundary_weight = nullptr, DF_REAL *vf = nullptr, DF_REAL *boundary_vf = nullptr,
                     DF_REAL *grad_vf = nullptr, DF_REAL *boundary_grad_vf = nullptr, int nVariate = 0, bool limited01 = false);

    void compute_upwind_weight(const DF_REAL *phi, DF_REAL *weight, DF_REAL *boundary_weight);
};

class Interpolation_limitedLinear : public Interpolation_base
{
public:
    Interpolation_limitedLinear() {};
    virtual ~Interpolation_limitedLinear() {};

    void interpolate(DF_REAL *weight, DF_REAL *boundary_weight = nullptr, DF_REAL *vf = nullptr, DF_REAL *boundary_vf = nullptr,
                     DF_REAL *grad_vf = nullptr, DF_REAL *boundary_grad_vf = nullptr, int nVariate = 1, bool limited01 = false);

    void compute_limitedLinear_weight(const DF_REAL *phi, const DF_REAL *vf, const DF_REAL *grad_vf, DF_REAL *weight,
                                      const DF_REAL *boundary_phi, const DF_REAL *boundary_vf,
                                      const DF_REAL *boundary_grad_vf, DF_REAL *boundary_weight, int nVariate = 1, bool limited01 = false);
};

class Interpolation_limitedLinearV : public Interpolation_base
{
public:
    Interpolation_limitedLinearV() {};
    virtual ~Interpolation_limitedLinearV() {};

    void interpolate(DF_REAL *weight, DF_REAL *boundary_weight = nullptr, DF_REAL *vf = nullptr, DF_REAL *boundary_vf = nullptr,
                     DF_REAL *grad_vf = nullptr, DF_REAL *boundary_grad_vf = nullptr, int nVariate = 1, bool limited01 = false);

    void compute_limitedLinearV_weight(const DF_REAL *phi, const DF_REAL *vf, const DF_REAL *grad_vf, DF_REAL *weight,
                                       const DF_REAL *boundary_phi, const DF_REAL *boundary_vf,
                                       const DF_REAL *boundary_grad_vf, DF_REAL *boundary_weight);
};

extern Interpolation_base *interpolation_base;

#endif