#ifndef _DFUEQN_H
#define _DFUEQN_H

#include "solver.h"

class dfUEqn : public solver_d
{
public:
    dfUEqn() {}
    virtual ~dfUEqn() {}

    void process();

    void getHbyA();

    void correctBCs();

    void getk();

    DF_REAL *d_diag_temp = nullptr;
    DF_REAL *d_grad_u = nullptr;
    DF_REAL *d_boundary_grad_u = nullptr;

    // if turbulence:
    DF_REAL *d_muEff = nullptr;
    DF_REAL *d_boundary_muEff = nullptr;

    void initStart();

protected:
    void setZero();

    void init();

    void freeinit();

    void assembly();

    void solve();

    void calculate_rAU();

    void getgradU();

    void getrAU();

    void getUEqnH();

    void correctBoundary_HbyA();

    void saveCoeffs_HbyA();

    void update_kEpsilon();

    void calculate_aveU(DF_REAL *boundary_rho, DF_REAL massFlowRate, DF_REAL &aveU);

#ifdef USE_GRAPH
    // one graph for one eqn before using self-developed solver
    cudaGraph_t graph_pre, graph_post;
    cudaGraphExec_t graph_instance_pre, graph_instance_post;
    bool pre_graph_created = false;
    bool post_graph_created = false;
#endif
};

extern dfUEqn UEqn_GPU;

#endif //_DFUEQN_H