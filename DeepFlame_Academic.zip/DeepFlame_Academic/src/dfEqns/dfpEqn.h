#ifndef _DFPEQN_H
#define _DFPEQN_H

#include "solver.h"

class dfpEqn : public solver_d
{
public:
    dfpEqn() {}
    virtual ~dfpEqn() {}

    void process();

    DF_REAL *d_rhorAUf = nullptr;
    DF_REAL *d_phiHbyA = nullptr;
    DF_REAL *d_flux = nullptr;

    DF_REAL *d_boundary_rhorAUf = nullptr;
    DF_REAL *d_boundary_phiHbyA = nullptr;
    DF_REAL *d_boundary_flux = nullptr;

    void initStart();

protected:
    void setZero();

    void init();

    void freeinit();

    void assembly();

    void solve();

    void correctBCs();

    void getrhorAUf();

    void getphiHbyA();

    void getdpdt();

    void updatePhi();

    void correctVelocity();

    void correctionDiagMtxMultiTPsi(
        DF_REAL *psi, DF_REAL *thermo_psi, DF_REAL *diag, DF_REAL *source);

#ifdef USE_GRAPH
    // one graph for one eqn before using self-developed solver
    cudaGraph_t graph_pre, graph_post;
    cudaGraphExec_t graph_instance_pre, graph_instance_post;
    bool pre_graph_created = false;
    bool post_graph_created = false;
#endif
};

extern dfpEqn pEqn_GPU;

#endif //_DFPEQN_H