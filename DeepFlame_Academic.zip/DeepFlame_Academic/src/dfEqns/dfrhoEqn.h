#ifndef _DFRHOEQN_H
#define _DFRHOEQN_H

#include "solver.h"

class dfrhoEqn : public solver_d
{
public:
    dfrhoEqn() {}
    virtual ~dfrhoEqn() {}

    void process();

    void initStart();

    void setZero();

protected:
    void init();

    void freeinit();

    void assembly();

    void solve();

    void correctBCs();

#ifdef USE_GRAPH
    // one graph for one eqn before using self-developed solver
    cudaGraph_t graph;
    cudaGraphExec_t graph_instance;
    bool graph_created = false;
#endif
};

extern dfrhoEqn rhoEqn_GPU;

#endif //_DFRHOEQN_H