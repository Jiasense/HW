#ifndef _DFEEQN_H
#define _DFEEQN_H

#include "solver.h"

class dfEEqn : public solver_d
{
public:
    dfEEqn() {}
    virtual ~dfEEqn() {}

    void process();

    void initStart();

protected:
    void setZero();

    void init();

    void freeinit();

    void assembly();

    void solve();

    void correctBCs();

    void calculate_energy_gradient();

#ifdef USE_GRAPH
    // one graph for one eqn before using self-developed solver
    cudaGraph_t graph_pre, graph_post;
    cudaGraphExec_t graph_instance_pre, graph_instance_post;
    bool pre_graph_created = false;
    bool post_graph_created = false;
#endif
};

extern dfEEqn EEqn_GPU;

#endif //_DFEEQN_H