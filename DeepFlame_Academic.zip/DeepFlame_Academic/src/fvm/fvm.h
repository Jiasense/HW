#include "common.h"

#ifndef _FVM_H
#define _FVM_H

namespace fvm
{
    void update_boundary_coeffs(int *patch_type, DF_REAL *value_internal_coeffs, DF_REAL *value_boundary_coeffs,
                                DF_REAL *gradient_internal_coeffs, DF_REAL *gradient_boundary_coeffs,
                                DF_REAL *boundary_value = nullptr, DF_REAL *boundary_grad = nullptr, DF_REAL *cell_value = nullptr, 
                                DF_REAL *boundary_refValue = nullptr);

    void update_boundary_coeffs_vector(int *patch_type, DF_REAL *value_internal_coeffs, DF_REAL *value_boundary_coeffs,
                                       DF_REAL *gradient_internal_coeffs, DF_REAL *gradient_boundary_coeffs,
                                       DF_REAL *boundary_value = nullptr, DF_REAL *boundary_grad = nullptr, DF_REAL *cell_value = nullptr);

    void ddt_scalar(DF_REAL *vf_old, DF_REAL *diag, DF_REAL *source, DF_REAL sign = 1.);

    void ddt_vector(DF_REAL *rho, DF_REAL *rho_old, DF_REAL *vf,
                    DF_REAL *diag, DF_REAL *source, DF_REAL sign = 1.);

    void ddt_vol_scalar_vol_scalar(DF_REAL *rho, DF_REAL *rho_old, DF_REAL *vf,
                                   DF_REAL *diag, DF_REAL *source, DF_REAL sign = 1.);

    // Use for calculated weight
    void div_scalar(DF_REAL *phi, DF_REAL *lower, DF_REAL *upper, DF_REAL *diag, DF_REAL *boundary_phi,
                    DF_REAL *value_internal_coeffs, DF_REAL *value_boundary_coeffs,
                    DF_REAL *internal_coeffs, DF_REAL *boundary_coeffs,
                    DF_REAL *weight, DF_REAL *boundary_weight, DF_REAL sign = 1.);

    // Use scheme to calculte weight
    void div_scalar(DF_REAL *phi, DF_REAL *lower, DF_REAL *upper, DF_REAL *diag, DF_REAL *boundary_phi,
                    DF_REAL *value_internal_coeffs, DF_REAL *value_boundary_coeffs,
                    DF_REAL *internal_coeffs, DF_REAL *boundary_coeffs, DF_REAL sign = 1.,
                    INTERPOLATION_SCHEME scheme = linear, DF_REAL *vf = nullptr, DF_REAL *boundary_vf = nullptr, 
                    int *patch_type = nullptr, DF_REAL *refValue = nullptr, DF_REAL *snGrad = nullptr);

    void div_vector(DF_REAL *phi, DF_REAL *lower, DF_REAL *upper, DF_REAL *diag, DF_REAL *boundary_phi,
                    DF_REAL *value_internal_coeffs, DF_REAL *value_boundary_coeffs,
                    DF_REAL *internal_coeffs, DF_REAL *boundary_coeffs, DF_REAL sign = 1.,
                    INTERPOLATION_SCHEME scheme = linear, DF_REAL *vf = nullptr, DF_REAL *boundary_vf = nullptr, 
                    int *patch_type = nullptr);              

    void laplacian_scalar(DF_REAL *lower, DF_REAL *upper, DF_REAL *diag,
                          DF_REAL *gamma, DF_REAL *boundary_gamma,
                          DF_REAL *gradient_internal_coeffs, DF_REAL *gradient_boundary_coeffs,
                          DF_REAL *internal_coeffs, DF_REAL *boundary_coeffs, DF_REAL sign = 1.);

    void laplacian_vector(DF_REAL *lower, DF_REAL *upper, DF_REAL *diag,
                          DF_REAL *gamma, DF_REAL *boundary_gamma,
                          DF_REAL *gradient_internal_coeffs, DF_REAL *gradient_boundary_coeffs,
                          DF_REAL *internal_coeffs, DF_REAL *boundary_coeffs, DF_REAL sign = 1.);

    void laplacian_surface_scalar_vol_scalar(DF_REAL *gamma, DF_REAL *lower, DF_REAL *upper, DF_REAL *diag,
                                             DF_REAL *boundary_gamma,
                                             DF_REAL *gradient_internal_coeffs, DF_REAL *gradient_boundary_coeffs,
                                             DF_REAL *internal_coeffs, DF_REAL *boundary_coeffs, DF_REAL sign = 1.);

    void SuSp_scalar(DF_REAL *susp, DF_REAL *vf, DF_REAL *diag, DF_REAL *source, DF_REAL sign = 1.);

    void Sp_scalar(DF_REAL *sp, DF_REAL *diag, DF_REAL sign = 1.);
}

#endif //_FVM_H