#pragma once
#include "common.h"
#include "mpi.h"

void divide_volume_vector(DF_REAL *vf);

void field_add_vector(DF_REAL *input1, DF_REAL *input2, DF_REAL *output, DF_REAL sign = 1.0);

void field_add_scalar(int num, DF_REAL *input1, DF_REAL *input2, DF_REAL *output,
                      DF_REAL *boundary_input1, DF_REAL *boundary_input2, DF_REAL *boundary_output, DF_REAL sign = 1.0);

void field_add_constant(int num, DF_REAL *input, DF_REAL *boundary_input,
                        DF_REAL *output, DF_REAL *boundary_output, DF_REAL constValue);

void field_divide_scalar(int num, DF_REAL *input1, DF_REAL *input2, DF_REAL *output,
                         DF_REAL *boundary_input1, DF_REAL *boundary_input2, DF_REAL *boundary_output);

void field_divide_scalar(int num, DF_REAL *input1, DF_REAL *input2, DF_REAL *output);

void field_multiply_scalar(int num, DF_REAL *input1, DF_REAL *input2, DF_REAL *output,
                           DF_REAL *boundary_input1, DF_REAL *boundary_input2, DF_REAL *boundary_output);

void field_multiply_scalar_boundary(DF_REAL *boundary_input1, DF_REAL *boundary_input2,
                                    DF_REAL *boundary_output);

void vector_half_mag_square(int num, DF_REAL *vec_input, DF_REAL *scalar_output,
                            DF_REAL *boundary_vec_input, DF_REAL *boundary_scalar_output);

void scalar_field_multiply_vector_field(DF_REAL *scalar_input, DF_REAL *vector_input, DF_REAL *output);

void scalar_field_multiply_vector_field(DF_REAL *scalar_input, DF_REAL *vector_input, DF_REAL *output,
                                        DF_REAL *scalar_boundary_input, DF_REAL *vector_boundary_input, DF_REAL *boundary_output, DF_REAL sign = 1.0);

void scale_dev2T_tensor(DF_REAL *vf1, DF_REAL *vf2, DF_REAL *boundary_vf1, DF_REAL *boundary_vf2);

void fvMtx_flux(int *patch_type, DF_REAL *lower, DF_REAL *upper,
                DF_REAL *psi, DF_REAL *output, DF_REAL *internal_coeffs, DF_REAL *boundary_coeffs,
                DF_REAL *boundary_psi, DF_REAL *boundary_output);

void bound_scalarField(int *patch_type, DF_REAL *field, DF_REAL *boundaryfield, DF_REAL lowerBound);

void surfaceSum(DF_REAL *ssf, DF_REAL *boudary_ssf, DF_REAL *output, DF_REAL *boundary_output);

void surfaceSum_vector(DF_REAL *ssf, DF_REAL *boudary_ssf, DF_REAL *output, DF_REAL *boundary_output, bool correctBCs = false);

void surfaceSum_tensor(DF_REAL *ssf, DF_REAL *boudary_ssf, DF_REAL *output, DF_REAL *boundary_output, bool correctBCs = false);

void surfaceSum_multiply(DF_REAL *ssf1, DF_REAL *boudary_ssf1, DF_REAL *ssf2, DF_REAL *boudary_ssf2, DF_REAL *output, DF_REAL *boundary_output);

DF_REAL getMinValue(DF_REAL *field, int N, bool global = false);

DF_REAL getMaxValue(DF_REAL *field, int N, bool global = false);

DF_REAL getSumValue(DF_REAL *field, int N, bool global = false);

void preTimeStep_basic(DF_REAL deltaT);

void writeResults_basic();

void copy2host_u_basic();

void copy2device_boundary_u_basic();

/* ----- COMMON OPERATIONS ----- */
// divide
void vector_divide_scalar(int num, DF_REAL *input_vector, DF_REAL *input_scalar, DF_REAL *output_vector);

// outer product
void vector_multiply_vector(int num, DF_REAL *vector_input1, DF_REAL *vector_input2, DF_REAL *output_tensor);

void vector_multiply_scalar(int num, DF_REAL *vector_input, DF_REAL *scalar_input, DF_REAL *output_vector);

// inner product
void tensor_innerProduct_vector(int num, DF_REAL *input_tensor, DF_REAL *input_vector, DF_REAL *output_vector);

// inverse
void inverse_tensor(int num, DF_REAL *input_tensor, DF_REAL *output_tensor);