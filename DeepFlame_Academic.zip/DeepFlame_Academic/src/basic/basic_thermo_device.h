#include "dfacademic.h"
#include "common.h"
#include "dfThermo.h"

#ifndef _BASIC_THERMO_DEVICE_H
#define _BASIC_THERMO_DEVICE_H

inline __device__ DF_REAL calculate_enthalpy_device_kernel(int num_total, int num_species, int index, DF_REAL local_T,
                                                           DF_REAL *mass_fraction, DF_REAL *d_nasa_coeffs, DF_REAL *d_molecular_weights)
{
    DF_REAL h = 0.;
    DF_REAL sum_mass_fraction_inv = 0.;
    for (int i = 0; i < num_species; i++)
    {
        sum_mass_fraction_inv += mass_fraction[i * num_total + index];
    }
    sum_mass_fraction_inv = 1. / sum_mass_fraction_inv;

    for (int i = 0; i < num_species; i++)
    {
        if (local_T > d_nasa_coeffs[i * 15 + 0])
        {
            h += (d_nasa_coeffs[i * 15 + 1] + d_nasa_coeffs[i * 15 + 2] * local_T / 2 + d_nasa_coeffs[i * 15 + 3] * local_T * local_T / 3 +
                  d_nasa_coeffs[i * 15 + 4] * local_T * local_T * local_T / 4 + d_nasa_coeffs[i * 15 + 5] * local_T * local_T * local_T * local_T / 5 +
                  d_nasa_coeffs[i * 15 + 6] / local_T) *
                 GAS_CANSTANT * local_T / d_molecular_weights[i] * mass_fraction[i * num_total + index] * sum_mass_fraction_inv;
        }
        else
        {
            h += (d_nasa_coeffs[i * 15 + 8] + d_nasa_coeffs[i * 15 + 9] * local_T / 2 + d_nasa_coeffs[i * 15 + 10] * local_T * local_T / 3 +
                  d_nasa_coeffs[i * 15 + 11] * local_T * local_T * local_T / 4 + d_nasa_coeffs[i * 15 + 12] * local_T * local_T * local_T * local_T / 5 +
                  d_nasa_coeffs[i * 15 + 13] / local_T) *
                 GAS_CANSTANT * local_T / d_molecular_weights[i] * mass_fraction[i * num_total + index] * sum_mass_fraction_inv;
        }
    }
    return h;
}

inline __device__ void calculate_enthalpy(int num_thread, int index, int offset, int num_total, int num_species,
                                          DF_REAL *T, DF_REAL *mass_fraction, DF_REAL *&enthalpy, DF_REAL *nasa_coeffs, DF_REAL *molecular_weights)
{
    int startIndex = index + offset;
    enthalpy[startIndex] = calculate_enthalpy_device_kernel(num_total, num_species, startIndex, T[startIndex],
                                                            mass_fraction, nasa_coeffs, molecular_weights);
}

inline __device__ DF_REAL calculate_chemical_enthalpy_device_kernel(int num_total, int num_species, int index,
                                                                    DF_REAL *mass_fraction, DF_REAL *d_Hf298SS, DF_REAL *d_molecular_weights)
{
    DF_REAL chemicalEnthalpy = 0;
    for (int i = 0; i < num_species; i++)
    {
        chemicalEnthalpy += mass_fraction[i * num_total + index] * d_Hf298SS[i] / d_molecular_weights[i];
    }
    return chemicalEnthalpy;
}

#endif //_BASIC_THERMO_DEVICE_H