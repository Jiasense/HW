#include <stdio.h>
#include <unistd.h>
#include <cuda_runtime.h>

#ifdef USE_LIBTORCH
#include <torch/script.h>
#endif

#include <dfacademic.h>
#include <common.h>
#include "opencc.h"

class Chemistry_solver_base{

public:
    Chemistry_solver_base() {};
    virtual ~Chemistry_solver_base() {};

    virtual void Initialize(int batch_size, DF_REAL unReactT) = 0;

    virtual void compute_RR(DF_REAL *d_T, DF_REAL *p, DF_REAL *y, DF_REAL *rho, DF_REAL *RR) = 0;

    void sync();
};

class Chemistry_solver_DNN : public Chemistry_solver_base{

#ifdef USE_LIBTORCH

private:
    data_para_ &dataBase_;
    mesh_para_ &meshBase_;

    std::vector<torch::jit::script::Module> modules_;
    torch::Device device_;

    DF_REAL *Xmu_, *Xstd_, *Ymu_, *Ystd_;
    DF_REAL *init_input_, *y_input_BCT, *NN_output_;
    int *d_reactCellIndex;
    int dim_input_, num_cells_, num_species_, num_modules_;
    int batch_size_;
    DF_REAL unReactT_;
    int inputsize_;
    
public:

    Chemistry_solver_DNN(data_para_ &dataBase, mesh_para_ &meshBase)
        : device_(torch::kCUDA), dataBase_(dataBase), meshBase_(meshBase) {};
    ~Chemistry_solver_DNN() {};

    void Initialize(int batch_size, DF_REAL unReactT);

    void compute_RR(DF_REAL *d_T, DF_REAL *p, DF_REAL *y, DF_REAL *rho, DF_REAL *RR);
#endif

};

class Chemistry_solver_opencc : public Chemistry_solver_base{

public:
    Chemistry_solver_opencc() {};
    ~Chemistry_solver_opencc() {};

    void Initialize(int batch_size, DF_REAL unReactT);

    void compute_RR(DF_REAL *d_T, DF_REAL *p, DF_REAL *y, DF_REAL *rho, DF_REAL *RR);
};

extern Chemistry_solver_base *chemistry_solver_base;
