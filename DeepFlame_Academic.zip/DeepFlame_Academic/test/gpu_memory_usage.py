import subprocess
import time

def get_nvidia_smi_gpu_memory_usage():
    try:
        smi_output = subprocess.check_output("nvidia-smi --query-gpu=memory.used --format=csv", shell=True).decode('utf-8')
        memory_usage = smi_output.strip().split('\n')[1:]
        return memory_usage
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

def log_gpu_memory_usage(filename, interval=1):
    with open(filename, 'a') as file:
        while True:
            memory_usage = get_nvidia_smi_gpu_memory_usage()
            if memory_usage:
                timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                file.write(f"{timestamp}, {', '.join(memory_usage)}\n")
                file.flush()
            time.sleep(interval)

log_gpu_memory_usage('gpu_memory_usage.log')