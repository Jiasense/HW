"""
This script is designed to compare results with OpenFOAM to test accuracy of GPU code,
such as matrix coeffs, and solved results of key variables.

Usage:
    python {DeepFlame_Academic_Path}/test/compareResults_toOpenFOAM.py  --tol [1E-10] --reltol [1E-10] --printFlag [False]

Options:
    --tol         Tolerance of absolute error
    --reltol      Tolerance of relative error
    --printFlag   Flag to print values when error larger than tolerance

NOTICE:
    Make sure [dfLowMachFoam] can run successfully in current path. 
"""


import os
import argparse

def output_relDiff(list1, list2, relTol):
    if len(list1) != len(list2):
        print(f"   >>> ERROR DATA: Data length mismatch !!!")

    index = 0
    diff_results = []
    for num1, num2 in zip(list1, list2):
        index = index + 1
        if ((abs(num1) > 0 and abs(num1 - num2) / abs(num1) > relTol) or 
            (abs(num2) > 0 and abs(num1 - num2) / abs(num2) > relTol)):
            diff_results.append([index, num1, num2, abs(num1 - num2)])

    return diff_results

def output_diff(list1, list2, tol):
    if len(list1) != len(list2):
        print(f"   >>> ERROR DATA: Data length mismatch !!!")

    index = 0
    diff_results = []
    for num1, num2 in zip(list1, list2):
        index = index + 1
        if (abs(num1 - num2) > tol):
            diff_results.append([index, num1, num2, abs(num1 - num2)])

    return diff_results


def compare_directory(directory, tol, relTol, printFlag=False):

    for filename in sorted(os.listdir(directory)):

        if filename.endswith(".host"):

            cpu_results = []
            gpu_results = []
            basename = os.path.splitext(filename)[0]
            # CPU
            with open(os.path.join(directory, filename), 'r') as file:
                content = file.read()
                for line in content.splitlines():
                    cpu_result = float(line)
                    cpu_results.append(cpu_result)

            # GPU
            filename_device = basename + '.device'
            if (not os.path.exists(os.path.join(directory, filename_device))):
                continue

            print("* Compare files:", filename_device, filename)
            with open(os.path.join(directory, filename_device), 'r') as file:
                content = file.read()
                for line in content.splitlines():
                    gpu_result = float(line)
                    gpu_results.append(gpu_result)

            diff_results = output_diff(cpu_results, gpu_results, tol)
            relDiff_results = output_relDiff(cpu_results, gpu_results, relTol)
            if (len(diff_results) > 0 or len(relDiff_results) > 0):
                print(f"   >>> NOTICE: Diff larger than {tol} found in: {basename}, diff size: {len(diff_results)}, relDiff size: {len(relDiff_results)}")
                if(printFlag): 
                    for diff in diff_results:
                        print(diff)
            else:
                print(f"   >>> No error larger than {tol} in: {basename}")
            print("")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Compare GPU results with CPU')
    parser.add_argument('--tol', type=float, required=False, default=1E-10, help='abs tol')
    parser.add_argument('--reltol', type=float, required=False, default=1E-10, help='rel tol')
    parser.add_argument('--printFlag', type=bool, required=False, default=False, help='print diff larger than tol (or reltol) values')

    args = parser.parse_args()

    print(f"SET tol: {args.tol}, relTol: {args.reltol}, printFlag: {args.printFlag}")

    cmd = f'dfLowMachFoam -compareResults'
    status = os.system(cmd)
    print(f"status: {status}, cmd: {cmd}")

    compare_directory(f'.', tol=args.tol, relTol=args.reltol, printFlag=args.printFlag)

