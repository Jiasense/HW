#ifndef _DFGAMG_H
#define _DFGAMG_H

#include "dfacademic.h"  

#if defined(__cplusplus)
extern "C" {
#endif // __cplusplus

/** A structure for storing GAMG solver control parameters. 
 */
typedef struct GAMG_control_para_
{
    int  agglomeration_level;                   // (scalar) total gamg grid levels 
    int  cycle_type = 1;                        // (scalar) gamg cycle type: 1 for Vcycle, 2 for Wcycle, 3 for Fcycle
    int  nCellsInCoarsestLevel = 32;            // (scalar) cell number of the coarest level grid

    int  nVcycles = 1;                          // (scalar) number of loop iterations for Vcycle 
    int  nPreSweeps = 2;                        // (scalar) number of smooth iterations in fine2coarse
    int  nPostSweeps = 2;                       // (scalar) number of smooth iterations in coarse2fine
    int  nFinestSweeps = 2;                     // (scalar) number of smooth iterations for finest level
    bool interpolateCorrection = false;         // (scalar) flag to use interpolate
    bool scaleCorrection = true;                // (scalar) flag to use scale (if matrix is symmetric, set "true")
    bool solveCoarsest = false;                 // (scalar) flag to use direct solve for coarest level 
                                                //                  (only support nCellsInCoarsestLevel=1, or =4 now) 
} GAMG_control_para;

/** A structure for storing GAMG multilevel mesh data in host. 
 */
typedef struct GAMG_mesh_para_
{
    int nCell;                                  // (scalar) number of cell for each level
    int nFace;                                  // (scalar) number of face for each level
    int patchSize;                              // (scalar) number of patch for each level

    int *nPatchFaces;                           // ([patchSize]) number of face for each patch

    int *restrictMap;                           // ([nCell]) map from finer level cell to coarser level cell
    int *faceRestrictMap;                       // ([nFace]) map from finer level face to coarser level face
    int *faceFlipMap;                           // ([nFace]) flag of flip, bool2int, 1 for true, 0 for false

    int *upperAddr;                             // ([nFace]) face neighbour addressing
    int *lowerAddr;                             // ([nFace]) face owner addressing

    int **faceCells = nullptr;                  // ([patchSize][nPatchFaces[patchi]]) map from face to cell in boundary region
    int **patchFaceRestrictMap = nullptr;       // ([patchSize][nPatchFaces[patchi]]) map from finer level face to coarser level face in boundary region
} GAMG_mesh_para;

/** Set for GAMG-mesh-related variables:
 *  \param[in] gamg_c       the struct about solver control parameters,
                            see "GAMG_control_para" struct for more.
 *  \param[in] gamg_m       the struct about gamg multilevel mesh data, [agglomeration_level]
                            see "GAMG_mesh_para" struct for more. 
 */
void set_GAMG(GAMG_control_para gamg_c, GAMG_mesh_para *gamg_m);

/** Set variables for GAMG ldu2csr:   
 *  \param[in] h_ldu_to_csr_no_diag     the map of ldu to csr (host)
 *  \param[in] h_csr_row_index_no_diag  the csr row array (host)
 *  \param[in] h_csr_col_index_no_diag  the csr col array (host)
 */
void set_GAMG_matrix_format_csr(
    int** h_ldu_to_csr_no_diag, 
    int** h_csr_row_index_no_diag, 
    int** h_csr_col_index_no_diag
);

/** Set variables for GAMG ldu2ell:   
 *  \param[in] h_ell_row_maxcount       The number of elements in the longest row (host)
 *  \param[in] h_ellCols                the ell col array (host)
 *  \param[in] h_ldu2ellIndex           the map of ldu to ell (host)
 */
void set_GAMG_matrix_format_ell(
    int* h_ell_row_maxcount, 
    int** h_ellCols, 
    int** h_ldu2ellIndex
);

#if defined(__cplusplus)
}
#endif //__cplusplus

#endif //_DFGAMG_H