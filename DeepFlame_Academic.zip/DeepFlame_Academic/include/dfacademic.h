#ifndef _DFACADEMIC_H
#define _DFACADEMIC_H

#include <stdio.h>  
#include <stdlib.h>  
#include <vector>
#include <iostream>

#if defined(__cplusplus)
extern "C" {
#endif // __cplusplus

#define DF_REAL double
#define NCCLREAL ncclDouble

/** An enumeration for choosing smoother.
 */
typedef enum 
{
    JACOBIAN = 0,       // Jacobi smoother
    SRJ      = 1        // Scheduled Relaxation Jacobi smoother
} MATRIX_SMOOTHER;

/** An enumeration for choosing preconditioner.
 */
typedef enum 
{
    GAMG_PRE = 0,        // GAMG preconditioner
    DIAGONAL_PRE = 1,    // Diagonal preconditioner
    JACOBI_PRE = 2
} MATRIX_PRECONDITIONER;

/** An enumeration for choosing matrix solver.
 */
typedef enum 
{
    DIAGONAL    = 0,    // Diagonal solver
    GAMG        = 1,    // GAMG solver
    PBICGSTAB   = 2,    // PBiCGStab solver
    PCG         = 3,    // PCG solver
    SMOOTHERPCG = 4     // SmootherPCG solver
} MATRIX_SOLVER;

/** An enumeration for choosing sparse matrix format.
 */
typedef enum
{
    CSR = 0,            // CSR format
    ELL = 1,            // ELL format
    AMGX_CSR = 2        // AMGX_CSR format
} MATRIX_SPARSE_FORMAT;

/** An enumeration for choosing equations.
 */
typedef enum 
{
    rhoEqn = 0,         // rho equation
    UEqn   = 1,         // U equation
    YEqn   = 2,         // Y equation
    EEqn   = 3,         // E equation
    pEqn   = 4,         // p equation
    kEqn   = 5,         // k equation
    epsilonEqn = 6,      // epsilon equation
    kEqn_LES = 7
} MATRIX_EQUATION;

/** An enumeration for choosing chemistry solver.
 */
typedef enum
{
    DNN = 0,            // DNN solver
    OpenCC = 1          // OpenCC solver
} CHEMISTRY_SOLVER;

/** An enumeration for choosing interpolation scheme.
 */
typedef enum
{
    linear = 0,           // linear interpolation
    upwind = 1,           // upwind interpolation
    limited_linear = 2,   // limited linear interpolation
    limited_linear01 = 3, // limited linear interpolation
    limited_linearV = 4   // limited linear interpolation vector
} INTERPOLATION_SCHEME;

/** An enumeration for choosing LES turbulence model.
 */
typedef enum
{
    les_none = 0,           // no model
    smagorinski = 1,    // Smagorinski model
    sigma = 2,           // Sigma model
    kEqnLES = 3         // kEqn model
} LES_TURBULENCE_MODEL;

/** An enumeration for choosing RANS turbulence model.
 */
typedef enum
{
    ras_none = 0,           // no model
    kepsilon = 1,       // k-epsilon model
    kOmega = 2,         // k-omega model
    SST = 3             // SST model
} RAS_TURBULENCE_MODEL;

/** An enumeration for choosing turbulence combustion interaction model.
 */
typedef enum
{
    WSR = 0,
    PaSR = 1,
    infinitelyFastChemistry = 2
} TCI_MODEL;

/** A structure for storing fvSchemes parameters.
 */
typedef struct fvSchemes_para_
{
    INTERPOLATION_SCHEME divSchemes_phi_U;
    INTERPOLATION_SCHEME divSchemes_phi_K;
    INTERPOLATION_SCHEME divSchemes_phid_p;
    INTERPOLATION_SCHEME divSchemes_phi_Yih;
    INTERPOLATION_SCHEME divSchemes_phi_k;
    INTERPOLATION_SCHEME divSchemes_phi_epsilon;
    INTERPOLATION_SCHEME divSchemes_hDiffCorrFlux;
    INTERPOLATION_SCHEME divSchemes_rho_nuEff;
} fvSchemes_para;

/** A structure for storing mesh parameters.
 */
typedef struct mesh_info_para_
{
    // constant values -- basic
    int num_cells             = 0;              // (scalar, const) number of cells in this rank
    int num_total_cells       = 0;              // (scalar, const) number of total cells in all ranks
    int num_patches           = 0;              // (scalar, const) number of patches
    int num_surfaces          = 0;              // (scalar, const) number of surfaces, = num_internalFaces
    int num_boundary_surfaces = 0;              // (scalar, const) number of boundary surface
    int num_proc_surfaces     = 0;

    const int *lowerAddr;                       // ([num_surfaces]) lower address
    const int *upperAddr;                       // ([num_surfaces]) upper address

    const DF_REAL *volume = nullptr;               // ([num_cells])
    const DF_REAL *mag_sf = nullptr;               // ([num_surfaces])
    const DF_REAL *delta_coeffs = nullptr;         // ([num_surfaces])
    const DF_REAL *weight = nullptr;               // ([num_surfaces])

    DF_REAL *mesh_dis = nullptr;                   // ([num_surfaces * 3]) 
    DF_REAL *sf = nullptr;                         // ([num_surfaces * 3])

    int *cyclicNeighbor;                        // ([num_patches]) neighbour processor addressing  
    int *neighbProcNo;                          // ([num_patches]) neighbour processor addressing    
    int *patch_size;                            // ([num_patches]) number of boundary face for each patch
    int *patch_offset;                          // ([num_patches])
    int *patch_start;                           // ([num_patches])
    int *interfaceFlag = nullptr;               // ([num_patches]) interface flag in boundary region

    int *boundary_face_cell = nullptr;          // ([nBoundarySurface]) map from face to cell in boundary region
    int *cell2face = nullptr;                   // ([num_cells*6]) map from cell to face in all 
    int *face2patch = nullptr;                  // ([num_boundary_surfaces]) map from face to patch in all

    DF_REAL *boundary_sf = nullptr;                // ([nBoundarySurface])
    DF_REAL *boundary_mag_sf = nullptr;            // ([nBoundarySurface])
    DF_REAL *boundary_delta_coeffs = nullptr;      // ([nBoundarySurface])
    DF_REAL *boundary_weight  = nullptr;           // ([nBoundarySurface])
    DF_REAL *boundary_weight_delta  = nullptr;     // ([nBoundarySurface])

    // for wedge boundary type
    DF_REAL *faceT = nullptr; // face transformation tensor: [num_patches*9]
    DF_REAL *cellT = nullptr; // neighbour-cell transformation tensor: [num_patches*9]
} mesh_info_para;


typedef struct init_data_para_
{
    DF_REAL rDeltaT = 0;
    DF_REAL p0 = 0;
    DF_REAL pRef = 0;
    DF_REAL massFlowRate = 0;

    int num_species = 0;
    int inertIndex = -1;

    DF_REAL *u = nullptr;
    DF_REAL *y = nullptr;
    DF_REAL *thermo_rhoD = nullptr;
    const DF_REAL *phi = nullptr;
    const DF_REAL *rho = nullptr;
    const DF_REAL *p = nullptr;
    const DF_REAL *he = nullptr;
    const DF_REAL *T = nullptr;
    const DF_REAL *k = nullptr;
    const DF_REAL *mu = nullptr;
    const DF_REAL *dpdt = nullptr;
    const DF_REAL *thermo_alpha = nullptr;
    const DF_REAL *thermo_psi = nullptr;
    const DF_REAL *p_rgh = nullptr;
    const DF_REAL *ph_rgh = nullptr;
    const DF_REAL *gh = nullptr;
    const DF_REAL *ghf = nullptr;
    
    DF_REAL *boundary_phi = nullptr;
    DF_REAL *boundary_rho = nullptr;
    DF_REAL *boundary_u = nullptr;
    DF_REAL *boundary_y = nullptr;
    DF_REAL *boundary_p = nullptr;
    DF_REAL *boundary_k = nullptr;
    DF_REAL *boundary_he = nullptr;
    DF_REAL *boundary_T = nullptr;
    DF_REAL *boundary_mu = nullptr;
    DF_REAL *boundary_thermo_alpha = nullptr;
    DF_REAL *boundary_thermo_rhoD = nullptr;    
    DF_REAL *boundary_thermo_psi = nullptr;
    DF_REAL *boundary_p_rgh = nullptr;
    DF_REAL *boundary_ph_rgh = nullptr;
    DF_REAL *boundary_gh = nullptr;
    DF_REAL *boundary_ghf = nullptr;
    DF_REAL *boundary_p_rgh_grad = nullptr;

    int *patch_type_rho = nullptr;
    int *patch_type_U = nullptr;
    int *patch_type_Y = nullptr;
    int *patch_type_p = nullptr;
    int *patch_type_p_rgh = nullptr;
    int *patch_type_he = nullptr;
    int *patch_type_k = nullptr;
    int *patch_type_T = nullptr;
    int *patch_type_calculated = nullptr;
    int *patch_type_extropolated = nullptr;

    DF_REAL *patch_refValue_Y =  nullptr;
    DF_REAL *patch_refValue_T =  nullptr;

} init_data_para;

typedef struct infinitelyFastChemistry_data_para_
{
    int O2Index; 
    int fuelIndex; 
    int *reactants = nullptr; 
    int *products = nullptr; // [num_species]
    DF_REAL s_; 
    DF_REAL stoicRatio_; 
    DF_REAL C_; 
    DF_REAL qFuel_;
    DF_REAL *fres = nullptr; // [num_cells*num_species]
    DF_REAL *Yprod0 = nullptr; // [num_species]
    DF_REAL *specieStoichCoeffs = nullptr; // [num_species]
} infinitelyFastChemistry_data_para;

typedef struct results_data_para_
{
    DF_REAL *h_u = nullptr;
    DF_REAL *h_T = nullptr;
    DF_REAL *h_y = nullptr;
    DF_REAL *h_rho = nullptr;
    DF_REAL *h_phi = nullptr;

    DF_REAL *h_boundary_u = nullptr;
    DF_REAL *h_boundary_T = nullptr;

    DF_REAL *h_HRR = nullptr;
    DF_REAL *h_phiHc = nullptr;
    DF_REAL *h_phiHs = nullptr;
    DF_REAL *h_phiH = nullptr;
} results_data_para;

extern results_data_para resultsData;

/** A structure for storing linear solver parameters.
 */
typedef struct matrix_solver_para_
{
    // linear solver control parameters
    int  maxIter   = 100;                        // (scalar, const) max iterations for linear solver 
    int  minIter   = 0;                          // (scalar, const) min iterations for linear solver 
    DF_REAL tolerance = 1e-9;                       // (scalar, const) absolute tolerance for linear solver
    DF_REAL reltol    = 0.01;                       // (scalar, const) relative tolerance for linear solver
    char* AMGXsettingPath = nullptr;
} matrix_solver_para;

/** Set variables for ldu2csr:   
 *  \param[in] h_ldu_to_csr     the map of ldu to csr (host)
 *  \param[in] h_csr_row_index  the csr row array (host)
 *  \param[in] h_csr_col_index  the csr col array (host)
 */
void set_matrix_format_amgx(
    int* h_ldu_to_csr, 
    int* h_csr_row_index, 
    int* h_csr_col_index
);

/** Set variables for ldu2csr:   
 *  \param[in] h_ldu_to_csr_no_diag     the map of ldu to csr (host)
 *  \param[in] h_csr_row_index_no_diag  the csr row array (host)
 *  \param[in] h_csr_col_index_no_diag  the csr col array (host)
 */
void set_matrix_format_csr(
    int* h_ldu_to_csr_no_diag, 
    int* h_csr_row_index_no_diag, 
    int* h_csr_col_index_no_diag
);

/** Set variables for ldu2ell:   
 *  \param[in] ell_row_maxcount         the max count of row
 *  \param[in] h_ellCols                the ell col array (host)
 *  \param[in] h_ldu2ellIndex           the map of ldu to ell (host)
 */
void set_matrix_format_ell(
    int ell_row_maxcount, 
    int* h_ellCols, 
    int* h_ldu2ellIndex
);

/** Set variables for mesh information:
 *  \param[in] mesh_paras           the struct about mesh information parameters,
                                    see "mesh_info_para" struct for more.
 *  \param[in] compareResults       the option to compare results with OpenFOAM.                                    
 */
void set_mesh_info(
    mesh_info_para mesh_paras,
    bool compareResults
);

/** Set variables for mesh information:
 *  \param[in] initData_paras       the struct about init physical variables,
                                    see "init_data_para" struct for more.
 */
void set_data_info(
    init_data_para initData_paras
);

/** Set constant coeffs for thermo:
 *  \param[in] mechanism_file       the mechanism file
 */
void set_thermo_const_coeffs(
    const char* mechanism_file,
    DF_REAL *Hf298SS = nullptr
);

/** Set fvSchemes:
 *  \param[in] fvSchemes            the struct of fvSchemes, see "fvSchemes_para" struct for more
 */
void set_schemes(
    fvSchemes_para fvSchemes
);

/** Set variables for linear solver:
 *  \param[in] solver_paras         the struct about linear solver parameters,
                                    see "matrix_solver_para" struct for more.
 *  \param[in] smoother             the enum for choosing smoother,
                                    see "MATRIX_SMOOTHER" enum for more.
 *  \param[in] preconditioner       the enum for choosing preconditioner,
                                    see "MATRIX_PRECONDITIONER" enum for more.
 *  \param[in] solver               the enum for choosing solver,
                                    see "MATRIX_SOLVER" enum for more.
 *  \param[in] sparse_format        the enum for choosing sparse matrix format,
                                    see "MATRIX_SPARSE_FORMAT" enum for more.
 *  \param[in] equation             the enum for choosing equations,
                                    see "MATRIX_EQUATION" enum for more.                                    
 */
void set_matrix_solver(
    matrix_solver_para solver_paras, 
    MATRIX_SMOOTHER smoother,
    MATRIX_PRECONDITIONER preconditioner,
    MATRIX_SOLVER solver,
    MATRIX_SPARSE_FORMAT sparse_format,
    MATRIX_EQUATION equation
);

/** Set variables for chemistry solver:
 *  \param[in] chemistry_solver_enum
 */
void set_chemistry_solver(CHEMISTRY_SOLVER chemistry_solver_enum);

/** Initialize chemistry solver:
 *  \param[in] batch_size
 *  \param[in] unReactT
 */
void initialize_chemistry_solver(int batch_size, DF_REAL unReactT);

/** Set variables for turbulence model:
 *  \param[in] turbulence
 *  \param[in] TCI
 *  \param[in] LES_model
 *  \param[in] RAS_model
 *  \param[in] patch_type_nut
 *  \param[in] patch_type_alphat
 */
void init_turbulence(
    bool turbulence,
    LES_TURBULENCE_MODEL LES_model,
    RAS_TURBULENCE_MODEL RAS_model,
    int *patch_type_nut = nullptr,
    int *patch_type_alphat = nullptr,
    int *patch_type_k = nullptr,
    int *patch_type_epsilon = nullptr,
    const DF_REAL *k_init = nullptr,
    const DF_REAL *epsilon_init = nullptr,
    DF_REAL *boundary_nut = nullptr,
    DF_REAL *boundary_alphat = nullptr,
    DF_REAL *boundary_k = nullptr,
    DF_REAL *boundary_epsilon = nullptr,
    DF_REAL *yDist = nullptr,
    DF_REAL *cornerWeights = nullptr,

    DF_REAL *intensity = nullptr,               // [num_patches]
    DF_REAL *mixingLength = nullptr,            // [num_patches]
    DF_REAL E = 9.8, 
    DF_REAL kappa = 0.41, 
    DF_REAL Cmu = 0.09,
    DF_REAL *patch_refValue_k =  nullptr
);

/** Set variables for turbulence model:
 *  \param[in] combustion_model
 */
void init_sgs_combustion(
    TCI_MODEL combustion_model,
    infinitelyFastChemistry_data_para input_data
);

/** Initialize matrix equation AX=b using linear solver:
 *      including setSolver, initSolvePerformance, and initialize (i.e. malloc),
 *      please ensure that all of the above content has been correctly set.
 *  \param[in] equation             the enum for choosing equations, see "MATRIX_EQUATION" enum for more.   
 */
void initialize_matrix(MATRIX_EQUATION equation);

/** Process equation:
 *      including assemply, solve, and malloc,
 *      please ensure that all of the above content has been correctly set.
 *  \param[in] equation             the enum for choosing equations, see "MATRIX_EQUATION" enum for more.   
 */
void process_equation(MATRIX_EQUATION equation);

/** Save pre-timestep physical variables:
 *      including rho, phi, U, k, p. 
 */
void preTimeStep(DF_REAL deltaT);

/** Update rho after pimple loop. 
 */
void updateRho();

/** Correct turbulence after pimple loop. 
 */
void correctTurbulence();

/** memcpy results d2h. 
 */
void writeResults();

/** copy d_u to host. 
 */
void copy2host_u();

/** copy h_boundary_u to device. 
 */
void copy2device_boundary_u();

/** init nccl. 
 */
void initNccl();


/** Obtain device ID.
 */
int get_device_ID();


#define TIME_MONITOR

#ifdef TIME_MONITOR
    extern DF_REAL time_monitor_rhoEqn_solve_GPU;
    extern DF_REAL time_monitor_UEqn_solve_GPU;
    extern DF_REAL time_monitor_YEqn_solve_GPU;
    extern DF_REAL time_monitor_EEqn_solve_GPU;
    extern DF_REAL time_monitor_pEqn_solve_GPU;
    extern DF_REAL time_monitor_chemistry_correctThermo_GPU;

    extern clock_t start_solve_gpu, end_solve_gpu;
#endif

#if defined(__cplusplus)
}
#endif //__cplusplus

#endif //_DFACADEMIC_H