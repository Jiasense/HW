## INTRODUCTION
DeepFlame is a combustion simulation software package. This repository integrates the code part of DeepFlame GPU-accelerated flow solver, and carries out normative code refactoring to better serve the academic community.
## INSTALLATION
### build
Compile using Makefile
```shell
make clean
make
```
Compile using CMakeLists.txt
```shell
mkdir build
cd build
cmake ..
make
```

### Sugon DCU platform 
```shell
make clean
make mkdir
make
```

## RUNNING
To execute this code library, you need to reference the header files in the _include_ directory and link the **libdfacademic.so** files in the _build_ or _lib_ directory within your main program. Then, invoke the functionalities of this code library within your main program. 

For further details, please refer to the deepflame code repository at https://github.com/deepmodeling/deepflame-dev/blob/dfAcademic/README.md.

## Directory Structure of the Package
### inlcude
This directory contains the header files required for external main program calls.

### src
This directory encompasses all the functional modules required for simulation calculations:
1. **basic**: contains modules for conventional vector and tensor operations.
2. **boundary**: contains modules related to boundary condition calculations.
3. **fvc**: contains calculations related to explicit derivatives.
4. **fvm**: contains calculations related to implicit derivatives
5. **interpolation**: contains calculations related to the discrete schemes of the div operator.
6. **matrix**: contains modules related to solving linear equations.
7. **turbulence**: contains modules related to turbulence models and combustion models.
8. **chemistry**: contains modules related to chemical reaction source terms.
9. **dfEqns_df*Foam**: contains modules for the assembly and solver of each physical equations to be solved, where _dfEqns_ corresponds to the solver _dfLowMachFoam_, and _dfEqns dfBuoyancyFoam_ corresponds to the solver _dfBuoyancyFoam_.

### test
This directory contains code related to testing the correctness of the programs within this code repository.